#!/usr/bin/env python3
"""Archive source identity and environment without initializing a GPU worker."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tarfile
from datetime import datetime
from pathlib import Path


def digest(path: Path) -> str:
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest() if hasattr(hashlib, "file_digest") else hashlib.sha256(source.read()).hexdigest()


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(root), *args], text=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sim-root", type=Path, required=True)
    parser.add_argument("--aic-source", type=Path, required=True)
    parser.add_argument("--kernel-stage", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    sim = args.sim_root.resolve()
    source = sim.parents[1]
    out = args.out_dir
    out.mkdir(parents=True, exist_ok=False)
    identity = {
        "captured_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "python": sys.executable,
        "python_version": sys.version,
        "source_root": str(source),
        "source_revision": git(source, "rev-parse", "HEAD").strip(),
        "aic_root": str(args.aic_source.resolve()),
        "aic_revision": git(args.aic_source, "rev-parse", "HEAD").strip(),
        "kernel_stage": str(args.kernel_stage.resolve()),
        "ninja_path": shutil.which("ninja"),
        "pythonpath": sys.path,
        "environment": {key: value for key, value in os.environ.items()
                        if key.startswith("SGLANG_") or key in ("PYTHONNOUSERSITE", "PYTHONPATH", "OMP_NUM_THREADS", "CUDA_HOME", "CUDA_VISIBLE_DEVICES")},
        "distributions": {},
        "module_origins": {},
    }
    for name in ("torch", "sglang", "sgl-kernel", "transformers", "triton", "numpy", "scikit-learn", "flashinfer-python", "python-docx", "ninja"):
        try:
            identity["distributions"][name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            identity["distributions"][name] = None
    for name in ("torch", "sglang", "sgl_kernel", "aiconfigurator", "sklearn", "gguf"):
        spec = importlib.util.find_spec(name)
        identity["module_origins"][name] = spec.origin if spec else None
    (out / "identity.json").write_text(json.dumps(identity, indent=2, ensure_ascii=False) + "\n")
    (out / "tracked_changes.patch").write_text(git(source, "diff", "HEAD", "--", "python/sglang", "tools/sglang-simulator"))
    (out / "git_status.txt").write_text(git(source, "status", "--short"))
    files = set()
    for folder in (sim / "src", sim / "scripts", sim / "tools", sim / "test"):
        files.update(path for path in folder.rglob("*") if path.is_file() and path.suffix in (".py", ".sh") and "__pycache__" not in path.parts)
    for relative in git(source, "diff", "--name-only", "HEAD", "--", "python/sglang").splitlines():
        path = source / relative
        if path.is_file():
            files.add(path)
    checksums = {str(path.relative_to(source)): digest(path) for path in sorted(files)}
    with tarfile.open(out / "experiment_sources.tar.gz", "w:gz") as archive:
        for path in sorted(files):
            archive.add(path, arcname=str(path.relative_to(source)))
    for path in sorted(args.kernel_stage.rglob("*.so")):
        checksums[str(path.resolve())] = digest(path)
    (out / "sha256.json").write_text(json.dumps(checksums, indent=2) + "\n")
    print(f"Provenance archived: {out}; source files={len(files)}")


if __name__ == "__main__":
    main()
