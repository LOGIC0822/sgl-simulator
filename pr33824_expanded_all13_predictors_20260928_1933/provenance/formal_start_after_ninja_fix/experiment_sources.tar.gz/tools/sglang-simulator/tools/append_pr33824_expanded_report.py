#!/usr/bin/env python3
"""Append workload-separated tables, learning curves and measured/predicted plots."""
from __future__ import annotations

import argparse
import csv
import os
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as source:
        return list(csv.DictReader(source))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"empty result table: {path}")
    with path.open("x", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def collect(root: Path, models: list[str], cases: list[str], repeats: int) -> tuple[list[dict], list[dict], list[dict]]:
    batch, e2e, curves = [], [], []
    for model in models:
        model_root = root / "models" / model
        for method, path in (("ML", "ml"), ("AIC", "aic")):
            rows = read_csv(model_root / "holdout" / f"{path}_teacher_forced" / "summary.csv")
            if {row["value"] for row in rows if row["group"] == "case"} != set(cases):
                raise ValueError(f"missing or extra batch workloads for {model}/{method}")
            for row in rows:
                if row["group"] not in ("case", "case_forward_mode"):
                    continue
                case, phase = row["value"], "all"
                if row["group"] == "case_forward_mode":
                    case, mode = case.rsplit(":", 1)
                    phase = {"mode1": "prefill", "mode2": "decode"}[mode]
                batch.append({"model": model, "method": method, "case": case, "phase": phase,
                              **{key: row[key] for key in ("n", "mean_actual_ms", "mean_predicted_ms", "mape_pct", "mae_ms", "p95_ape_pct", "mean_signed_error_pct")}})
            paired = read_csv(model_root / "holdout" / f"{path}_e2e_comparison" / "summary.csv")
            expected = {(case, metric) for case in cases for metric in ("mean_e2e_latency_ms", "mean_ttft_ms", "mean_tpot_ms", "total_throughput")}
            actual = set()
            for row in paired:
                if row["group"] != "case_metric":
                    continue
                case, metric = row["value"].rsplit(":", 1)
                if int(row["n"]) != repeats:
                    raise ValueError(f"wrong real repeat count for {model}/{case}/{method}")
                actual.add((case, metric))
                e2e.append({"model": model, "method": method, "case": case, "metric": metric,
                            **{key: row[key] for key in ("n", "real_mean", "real_std", "predicted_mean", "predicted_std", "mape_pct", "mean_signed_error_pct")}})
            if actual != expected:
                raise ValueError(f"incomplete paired workloads for {model}/{method}")
        for row in read_csv(model_root / "learning_curve" / "learning_curve.csv"):
            curves.append(dict(row))
    return batch, e2e, curves


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    metadata = dict(line.split("=", 1) for line in (args.results_root / "run_metadata.txt").read_text().splitlines() if "=" in line)
    models = metadata["models"].split(",")
    train_cases = metadata["training_case"].split(",")
    cases = metadata["heldout_case"].split(",")
    batch, e2e, curves = collect(args.results_root, models, cases, int(metadata["heldout_real_repeats"]))
    args.out_dir.mkdir(parents=True, exist_ok=False)
    write_csv(args.out_dir / "workload_batch_metrics.csv", batch)
    write_csv(args.out_dir / "workload_end_to_end_metrics.csv", e2e)
    write_csv(args.out_dir / "learning_curves.csv", curves)
    lines = ["", "## 同负载与跨负载测试", "",
             "前三类负载出现在训练数据中，但测试请求和 seed 独立；后两类负载不用于训练。跨负载不代表所有特征都在训练范围之外。以下按模型与负载列出实测值和预测值，避免把五类负载混成一个精度结论。", ""]
    rel = Path(os.path.relpath(args.out_dir, args.markdown.parent))
    for case in cases:
        label = "同负载独立测试" if case in train_cases else "跨负载测试"
        lines.extend([f"### {case}（{label}）", "",
                      "| 模型 | 方法 | 单步实测/预测 ms | 单步 MAPE / MAE ms | E2E 实测 ± std / 预测 ms | E2E MAPE | TTFT MAPE | TPOT MAPE | 吞吐实测/预测 req/s |",
                      "| --- | --- | --- | --- | --- | --- | --- | --- | --- |"])
        for model in models:
            for method in ("ML", "AIC"):
                b = next(row for row in batch if row["model"] == model and row["method"] == method and row["case"] == case and row["phase"] == "all")
                metrics = {row["metric"]: row for row in e2e if row["model"] == model and row["method"] == method and row["case"] == case}
                r = metrics["mean_e2e_latency_ms"]
                t = metrics["total_throughput"]
                f = lambda row, key: float(row[key])
                lines.append(f"| {model} | {method} | {f(b,'mean_actual_ms'):.2f} / {f(b,'mean_predicted_ms'):.2f} | {f(b,'mape_pct'):.2f}% / {f(b,'mae_ms'):.2f} | {f(r,'real_mean'):.2f} ± {f(r,'real_std'):.2f} / {f(r,'predicted_mean'):.2f} | {f(r,'mape_pct'):.2f}% | {f(metrics['mean_ttft_ms'],'mape_pct'):.2f}% | {f(metrics['mean_tpot_ms'],'mape_pct'):.2f}% | {f(t,'real_mean'):.2f} / {f(t,'predicted_mean'):.2f} |")
        lines.append("")
    for method in ("ML", "AIC"):
        for category in ("batch", "e2e"):
            rows = batch if category == "batch" else e2e
            selected = [row for row in rows if row["method"] == method and row.get("phase", "all") == "all" and row.get("metric", "mean_e2e_latency_ms") == "mean_e2e_latency_ms"]
            values = np.asarray([[float(next(row["mape_pct"] for row in selected if row["model"] == model and row["case"] == case)) for case in cases] for model in models])
            fig, ax = plt.subplots(figsize=(9, max(5, len(models) * .38)))
            picture = ax.imshow(values, aspect="auto", cmap="YlOrRd", vmin=0)
            ax.set_xticks(range(len(cases)), cases, rotation=25, ha="right", fontsize=8)
            ax.set_yticks(range(len(models)), models, fontsize=8)
            for i in range(len(models)):
                for j in range(len(cases)):
                    ax.text(j, i, f"{values[i,j]:.1f}", ha="center", va="center", fontsize=8)
            ax.set_title(f"{method}: {category} MAPE (%) by workload")
            fig.colorbar(picture, ax=ax, label="MAPE (%)")
            fig.tight_layout()
            filename = f"{method.lower()}_{category}_workload_heatmap.png"
            fig.savefig(args.out_dir / filename, dpi=180)
            plt.close(fig)
            lines.extend([f"![{method} {category} 分负载误差]({rel / filename})", ""])
    lines.extend(["## 训练量递增对比", "", "测试集保持不变，以前 1、3、5 组训练 trace 分别拟合，训练请求数为 160、480、800；下面曲线按负载展示。增加样本是否有效以实测误差变化为准，不预设单调改善。", ""])
    fig, axes = plt.subplots(4, 4, figsize=(17, 13), squeeze=False)
    for ax, model in zip(axes.flat, models):
        for case in cases:
            rows = sorted([row for row in curves if row["model"] == model and row.get("case") == case], key=lambda row: int(row["training_traces"]))
            if len(rows) != 3:
                raise ValueError(f"incomplete per-workload learning curve: {model}/{case}")
            ax.plot([int(row["training_traces"]) * 160 for row in rows], [float(row["mape_pct"]) for row in rows], marker="o", label=case)
        ax.set_title(model, fontsize=9)
        ax.set_xlabel("Training requests", fontsize=8)
        ax.set_ylabel("Batch MAPE (%)", fontsize=8)
        ax.grid(alpha=.25)
    for ax in list(axes.flat)[len(models):]:
        ax.set_visible(False)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, fontsize=9)
    fig.tight_layout(rect=(0, .06, 1, 1))
    fig.savefig(args.out_dir / "all_model_learning_curves.png", dpi=180)
    plt.close(fig)
    lines.extend([f"![各模型训练量曲线]({rel / 'all_model_learning_curves.png'})", "",
                  "完整 prefill/decode、P95 APE、偏差与样本数见同目录 workload_batch_metrics.csv；全部 E2E、TTFT、TPOT、吞吐及实机标准差见 workload_end_to_end_metrics.csv。", "",
                  "## 结果解释的边界", "",
                  "同步墙钟单步时延包含 run_batch 内 CPU 发射、采样/拷贝和同步等待，AIC 算子 GPU 时延求和不包含全部这些开销。因此增加 AIC 算子点与提高端到端准确性不是同一件事。AWQ BF16 代理、dual-chunk attention 代理与 MoE 路由覆盖限制沿用前文单列说明。当前 GPU 其他进程及显存状态已记录；本轮不是无干扰的硬件性能标定。", ""])
    args.markdown.write_text(args.markdown.read_text(encoding="utf-8") + "\n".join(lines), encoding="utf-8")
    print(f"workload batch rows={len(batch)} e2e rows={len(e2e)} curve rows={len(curves)}")


if __name__ == "__main__":
    main()
