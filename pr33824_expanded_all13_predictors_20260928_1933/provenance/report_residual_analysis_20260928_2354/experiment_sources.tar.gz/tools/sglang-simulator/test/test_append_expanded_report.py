"""Validate report completeness without launching servers or GPU workloads."""
from __future__ import annotations
import csv
import hashlib
import importlib.util
import json
import sys
import tarfile
from pathlib import Path
from types import SimpleNamespace

import joblib
import pytest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("expanded_report", ROOT / "tools/append_pr33824_expanded_report.py")
assert SPEC and SPEC.loader
report = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(report)


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def fixture_results(tmp_path, repeats=5):
    model = "Qwen3-0.6B"
    case = "latency_128x64_r1"
    model_root = tmp_path / "models" / model
    for method in ("ml", "aic"):
        batch = [{"group": group, "value": value, "n": "15", "mean_actual_ms": "2", "mean_predicted_ms": "1.8", "mape_pct": "10", "mae_ms": "0.2", "p95_ape_pct": "12", "mean_signed_error_pct": "-10"}
                 for group, value in (("case", case), ("case_forward_mode", case + ":mode1"), ("case_forward_mode", case + ":mode2"))]
        write_csv(model_root / "holdout" / f"{method}_teacher_forced" / "summary.csv", batch)
        pairs = [{"group": "case_metric", "value": case + ":" + metric, "n": str(repeats), "real_mean": "2", "real_std": "0.1", "predicted_mean": "1.8", "predicted_std": "0.1", "mape_pct": "10", "mean_signed_error_pct": "-10"}
                 for metric in ("mean_e2e_latency_ms", "mean_ttft_ms", "mean_tpot_ms", "total_throughput")]
        write_csv(model_root / "holdout" / f"{method}_e2e_comparison" / "summary.csv", pairs)
    write_csv(model_root / "learning_curve" / "learning_curve.csv", [{"model": model, "case": case, "training_traces": str(count), "phase": "all", "mape_pct": "10"} for count in (1, 3, 5)])
    return model, case


def test_report_has_batch_phases_and_all_metrics(tmp_path):
    model, case = fixture_results(tmp_path)
    batch, pairs, curves = report.collect(tmp_path, [model], [case], 5)
    assert len(batch) == 6
    assert len(pairs) == 8
    assert {row["phase"] for row in batch} == {"all", "prefill", "decode"}
    assert curves[0]["case"] == case


def residual_fixture(root):
    model = "example"
    source = root / "models" / model / "holdout/real/repeat-1/cases/case/TP0.schedule_batch.jsonl"
    for method in ("ml", "aic"):
        directory = root / "models" / model / "holdout" / f"{method}_teacher_forced"
        rows = [{"case": "case", "schedule_path": str(source), "line_number": index,
                 "forward_mode": 2, "batch_size": 1, "sum_extend": 1, "sum_past": index,
                 "actual_seconds": actual, "predicted_seconds": predicted}
                for index, (actual, predicted) in enumerate(((1.0, 2.0), (2.0, 2.0)), start=1)]
        write_csv(directory / "per_batch.csv", rows[::-1] if method == "aic" else rows)
        write_csv(directory / "summary.csv", [{"group": "all", "value": "all", "n": 2,
                  "mean_actual_ms": 1500, "mean_predicted_ms": 2000,
                  "rmse_ms": 1000 * .5 ** .5, "mape_pct": 50}])
    output = root / "residual_report"
    output.mkdir()
    return model, output


def test_residual_report_keeps_all_rows_and_accepts_reordered_scores(tmp_path):
    model, output = residual_fixture(tmp_path)
    lines = report.residual_concentration_details(tmp_path, [model], output)
    rows = report.read_csv(output / "residual_concentration.csv")
    assert len(rows) == 2 and {row["method"] for row in rows} == {"ML", "AIC"}
    assert all(int(row["n"]) == 2 and int(row["top_100_count"]) == 2 for row in rows)
    assert all(float(row["top_1_squared_error_pct"]) == 100 for row in rows)
    assert all(float(row["top_100_row_pct"]) == 100 for row in rows)
    assert len(report.read_csv(output / "largest_batch_residuals.csv")) == 4
    assert "不是 MAPE 占比" in "\n".join(lines)
    assert "未删除异常值" in "\n".join(lines)


def test_single_method_residual_readback_does_not_claim_ml_aic_comparison(tmp_path):
    model, output = residual_fixture(tmp_path)
    lines = report.residual_concentration_details(tmp_path, [model], output, methods=("ML",))
    assert "不表示已经完成 ML/AIC 的逐条对照" in "\n".join(lines)
    assert {row["method"] for row in report.read_csv(output / "residual_concentration.csv")} == {"ML"}


def test_residual_report_rejects_equal_mean_but_different_real_steps(tmp_path):
    model, output = residual_fixture(tmp_path)
    path = tmp_path / "models" / model / "holdout/aic_teacher_forced/per_batch.csv"
    rows = report.read_csv(path)
    rows[0]["actual_seconds"], rows[1]["actual_seconds"] = rows[1]["actual_seconds"], rows[0]["actual_seconds"]
    write_csv(path, rows)
    # Counts, actual/predicted means, RMSE and MAPE remain identical.
    with pytest.raises(ValueError, match="different individual observations"):
        report.residual_concentration_details(tmp_path, [model], output)


def test_residual_report_rejects_duplicate_observations(tmp_path):
    model, output = residual_fixture(tmp_path)
    path = tmp_path / "models" / model / "holdout/ml_teacher_forced/per_batch.csv"
    rows = report.read_csv(path)
    write_csv(path, [rows[0], rows[0]])
    with pytest.raises(ValueError, match="duplicate or invalid scored observation"):
        report.residual_concentration_details(tmp_path, [model], output)


def test_residual_report_rejects_nonfinite_prediction(tmp_path):
    model, output = residual_fixture(tmp_path)
    path = tmp_path / "models" / model / "holdout/ml_teacher_forced/per_batch.csv"
    rows = report.read_csv(path)
    rows[0]["predicted_seconds"] = "nan"
    write_csv(path, rows)
    with pytest.raises(ValueError, match="nonfinite or invalid scored latency"):
        report.residual_concentration_details(tmp_path, [model], output)


def test_residual_report_defines_zero_error_share_without_dropping_rows(tmp_path):
    model, output = residual_fixture(tmp_path)
    for method in ("ml", "aic"):
        directory = tmp_path / "models" / model / "holdout" / f"{method}_teacher_forced"
        rows = report.read_csv(directory / "per_batch.csv")
        for row in rows:
            row["predicted_seconds"] = row["actual_seconds"]
        write_csv(directory / "per_batch.csv", rows)
        summary = report.read_csv(directory / "summary.csv")
        summary[0].update(mean_predicted_ms=1500, rmse_ms=0, mape_pct=0)
        write_csv(directory / "summary.csv", summary)
    report.residual_concentration_details(tmp_path, [model], output)
    assert all(float(row["top_100_squared_error_pct"]) == 0 and int(row["n"]) == 2
               for row in report.read_csv(output / "residual_concentration.csv"))


def test_residual_report_rejects_summary_that_drops_a_batch(tmp_path):
    model, output = residual_fixture(tmp_path)
    path = tmp_path / "models" / model / "holdout/ml_teacher_forced/summary.csv"
    rows = report.read_csv(path)
    rows[0]["n"] = 1
    write_csv(path, rows)
    with pytest.raises(ValueError, match="per-batch rows disagree with summary"):
        report.residual_concentration_details(tmp_path, [model], output)


def test_formal_residual_report_requires_actual_scored_rows(tmp_path):
    identity = tmp_path / "provenance/formal_start_after_ninja_fix/identity.json"
    identity.parent.mkdir(parents=True)
    identity.write_text("{}")
    with pytest.raises(FileNotFoundError, match="per_batch.csv"):
        report.residual_concentration_details(tmp_path, ["example"], tmp_path)


def regression_record_fixture(root, failed=1, exit_code=1):
    verification = root / "verification"
    verification.mkdir()
    (verification / "full_suite_record.json").write_text(json.dumps({
        "date": "2026-09-28", "command": "python -m pytest -q test",
        "result": {"failed": failed, "passed": 47, "warnings": 5,
                   "elapsed_seconds": 395.2, "exit_code": exit_code},
        "scope_note": "CPU fixture，不是 GPU 精度实验。",
        "failure": {"test": "test_offline_blocking",
                    "outputs": {mode: f"verification/{mode}.json" for mode in ("offline", "blocking")},
                    "tolerances": {"mean_ttft_ms": .1},
                    "interpretation_note": "未放宽容差；尚未隔离原因。"},
    }))
    for mode, value in (("offline", 12.762786), ("blocking", 11.341969)):
        (verification / f"{mode}.json").write_text(json.dumps({"mean_ttft_ms": value}))


def test_report_discloses_full_suite_failure_from_saved_fixtures(tmp_path):
    regression_record_fixture(tmp_path)
    lines = report.regression_verification_details(tmp_path, tmp_path)
    assert "47 项通过、1 项失败" in "\n".join(lines)
    assert "退出码 1" in "\n".join(lines)
    assert "12.5271%" in "\n".join(lines)
    rows = report.read_csv(tmp_path / "full_suite_fixture_comparison.csv")
    assert float(rows[0]["relative_difference_pct"]) > float(rows[0]["tolerance_pct"])


def test_report_rejects_failed_full_suite_marked_success(tmp_path):
    regression_record_fixture(tmp_path, exit_code=0)
    with pytest.raises(ValueError, match="inconsistent full-suite result"):
        report.regression_verification_details(tmp_path, tmp_path)


def test_report_rejects_regression_record_not_reproduced_by_fixtures(tmp_path):
    regression_record_fixture(tmp_path)
    (tmp_path / "verification/offline.json").write_text(json.dumps({"mean_ttft_ms": 11.34}))
    with pytest.raises(ValueError, match="do not reproduce"):
        report.regression_verification_details(tmp_path, tmp_path)


def test_report_distinguishes_relative_bias_from_bias_of_means(tmp_path, monkeypatch):
    spec = importlib.util.spec_from_file_location(
        "comprehensive_report_bias_test",
        ROOT / "tools/summarize_pr33824_comprehensive_predictor_experiment.py",
    )
    assert spec and spec.loader
    base = importlib.util.module_from_spec(spec)
    monkeypatch.setitem(sys.modules, spec.name, base)
    spec.loader.exec_module(base)
    # Actual [1, 100], predictions [10, 90]: relative bias is +445%,
    # despite the prediction mean being below the actual mean.
    metrics = {"mean_actual_ms": 50.5, "mean_predicted_ms": 50.0,
               "mean_signed_error_pct": 445.0, "mape_pct": 455.0}
    record = {"model": "example", "complete": True,
              "train": base.BatchCounts(800, 2, 1, 1),
              "holdout": base.BatchCounts(1280, 2, 1, 1),
              "distribution": {}, "aic_manifest": {},
              "training_validation": {}, "settings": {},
              "teacher": {method: {phase: metrics for phase in ("all", "prefill", "decode")}
                          for method in base.METHODS},
              "e2e": {method: {"mean_e2e_latency_ms": {"mape_pct": 1.0}}
                      for method in base.METHODS}}
    support = {"grid": {"batch_sizes": [1], "context_input_lengths": [1],
                        "generation_input_lengths": [1]},
               **{key: {"context": 0, "generation": 0, "total": 0}
                  for key in ("expected", "new", "reused")}}
    counts = {key: 0 for key in ("source_rows", "retained_regular_context_rows",
                                 "retained_other_rows", "removed_sparse_or_incompatible_rows")}
    markdown = base.build_markdown(tmp_path, [record], {}, {}, support,
                                   {"row_counts": counts}, Path("figures"))
    assert "ML 平均相对偏差" in markdown
    assert "| example | 50.50 | 50.00 | 445.00% |" in markdown
    assert "不是 (预测均值−实测均值)/实测均值，两者可能符号不同" in markdown
    assert metrics["mean_signed_error_pct"] == 445.0


def replay_component_fixture(root, iterations=2):
    reference = root / "provenance/formal_start_after_ninja_fix/identity.json"
    reference.parent.mkdir(parents=True)
    reference.write_text("{}")
    (root / "run_metadata.txt").write_text("heldout_real_repeats=1\nheldout_case=case\n")
    path = root / "models/example/holdout/ml_simulator/repeat-1/cases/case/simulator-output"
    path.mkdir(parents=True)
    (path / "metrics.json").write_text(json.dumps({"iterations": iterations, "predictor_time_cost": .004}))
    (path / "iteration.jsonl").write_text("\n".join(json.dumps(row) for row in (
        {"cpu_overhead": .003, "forward_latency": .01},
        {"cpu_overhead": .004, "forward_latency": .02},
    )))


def test_replay_wall_time_audit_preserves_forward_predictions(tmp_path):
    replay_component_fixture(tmp_path)
    output = tmp_path / "audit"
    output.mkdir()
    lines = report.replay_overhead_details(tmp_path, ["example"], output, methods=("ML",))
    rows = report.read_csv(output / "replay_wall_time_components.csv")
    assert len(rows) == 1
    assert float(rows[0]["predictor_wall_ms_per_iteration"]) == 2
    assert float(rows[0]["accounted_cpu_ms_per_iteration"]) == 3.5
    assert float(rows[0]["predicted_forward_ms_per_iteration"]) == 15
    assert "不是独立测得的原生服务 CPU 时延" in "\n".join(lines)
    assert "没有事后扣除平均开销" in "\n".join(lines)


def test_replay_wall_time_audit_rejects_missing_iterations(tmp_path):
    replay_component_fixture(tmp_path, iterations=3)
    with pytest.raises(ValueError, match="iteration count mismatch"):
        report.replay_overhead_details(tmp_path, ["example"], tmp_path, methods=("ML",))


def test_report_rejects_incomplete_real_repeats(tmp_path):
    model, case = fixture_results(tmp_path, repeats=4)
    with pytest.raises(ValueError, match="wrong real repeat count"):
        report.collect(tmp_path, [model], [case], 5)


def test_report_rejects_missing_phase(tmp_path):
    model, case = fixture_results(tmp_path)
    path = tmp_path / "models" / model / "holdout/ml_teacher_forced/summary.csv"
    rows = report.read_csv(path)
    write_csv(path, rows[:-1])
    with pytest.raises(ValueError, match="batch phases"):
        report.collect(tmp_path, [model], [case], 5)


def test_report_rejects_different_ml_aic_real_observations(tmp_path):
    model, case = fixture_results(tmp_path)
    path = tmp_path / "models" / model / "holdout/aic_teacher_forced/summary.csv"
    rows = report.read_csv(path)
    rows[0]["mean_actual_ms"] = "2.1"
    write_csv(path, rows)
    with pytest.raises(ValueError, match="different real batch"):
        report.collect(tmp_path, [model], [case], 5)


def test_previous_comparison_requires_identical_real_samples(tmp_path):
    model, case = fixture_results(tmp_path)
    for method in ("ml", "aic"):
        original = report.read_csv(tmp_path / "models" / model / "holdout" / f"{method}_teacher_forced/summary.csv")
        write_csv(tmp_path / "previous_calibration/models" / model / f"{method}_teacher_forced/summary.csv", original)
    rows = report.previous_calibration_rows(tmp_path, [model])
    assert len(rows) == 6 and all(row["improvement_pp"] == 0 for row in rows)
    original[0]["n"] = "14"
    write_csv(tmp_path / "previous_calibration/models" / model / "aic_teacher_forced/summary.csv", original)
    with pytest.raises(ValueError, match="different real observations"):
        report.previous_calibration_rows(tmp_path, [model])


def request_identity_fixture(tmp_path):
    model = "Qwen3-0.6B"
    (tmp_path / "run_metadata.txt").write_text("training_requests_total=2\nheldout_requests_total=2\n")
    for role, payloads in (("calibration", [([1, 2], 8), ([3], 4)]),
                           ("holdout", [([1, 2], 9), ([5], 4)])):
        folder = tmp_path / "models" / model / role / "real/repeat-1/cases/fixture"
        folder.mkdir(parents=True)
        raw = [{"rid": f"{role}-{index}", "input_ids": prompt, "input_length": len(prompt), "output_length": length}
               for index, (prompt, length) in enumerate(payloads)]
        trace = [{"prompt": item["input_ids"], "prompt_len": item["input_length"], "output_len": item["output_length"], "metadata": {"source_rid": item["rid"]}} for item in raw]
        (folder / "TP0.raw_request.jsonl").write_text("".join(json.dumps(item) + "\n" for item in raw))
        (folder / "autobench_trace.jsonl").write_text("".join(json.dumps(item) + "\n" for item in trace))
    out = tmp_path / "identity_report"
    out.mkdir()
    return model, out


def test_request_identity_distinguishes_prompt_and_full_payload_overlap(tmp_path):
    model, out = request_identity_fixture(tmp_path)
    lines = report.request_identity_details(tmp_path, [model], out)
    row = report.read_csv(out / "train_test_request_identity.csv")[0]
    assert float(row["heldout_prompt_overlap_pct"]) == 50
    assert float(row["heldout_input_and_output_length_overlap_pct"]) == 0
    assert row["real_to_replay_ids_verified"] == "4"
    assert any("50.00%" in line for line in lines)


def test_request_identity_rejects_changed_replay_tokens(tmp_path):
    model, out = request_identity_fixture(tmp_path)
    path = tmp_path / "models" / model / "holdout/real/repeat-1/cases/fixture/autobench_trace.jsonl"
    trace = [json.loads(line) for line in path.read_text().splitlines()]
    trace[0]["prompt"] = [99, 100]
    path.write_text("".join(json.dumps(item) + "\n" for item in trace))
    with pytest.raises(ValueError, match="replay changes actual input"):
        report.request_identity_details(tmp_path, [model], out)


def test_aic_snapshot_checks_archived_bytes_not_just_revision(tmp_path):
    with pytest.raises(FileNotFoundError, match="missing formal AIC"):
        report.aic_source_snapshot_details(tmp_path, "fixture", required=True)
    folder = tmp_path / "aic_calibration/provenance_before_wide_sweep"
    folder.mkdir(parents=True)
    code = tmp_path / "collect_attn.py"
    code.write_text("# fixture, not measured data\n")
    identity = {"aic_revision": "fixture", "aic_source_snapshot": {"source_files": 1, "dirty": True},
                "aic_import_source_match": {"checked_python_files": 133, "mismatches": []}}
    (folder / "identity.json").write_text(json.dumps(identity))
    (folder / "aic_git_status.txt").write_text(" M collector/sglang/collect_attn.py\n")
    (folder / "aic_tracked_changes.patch").write_text("fixture patch\n")
    name = "collector/sglang/collect_attn.py"
    hashes = {name: hashlib.sha256(code.read_bytes()).hexdigest()}
    (folder / "aic_source_sha256.json").write_text(json.dumps(hashes))
    with tarfile.open(folder / "aic_collector_and_sdk_sources.tar.gz", "w:gz") as archive:
        archive.add(code, arcname=name)
    assert any("133" in line for line in report.aic_source_snapshot_details(tmp_path, "fixture", required=True))
    hashes[name] = "0" * 64
    (folder / "aic_source_sha256.json").write_text(json.dumps(hashes))
    with pytest.raises(ValueError, match="checksum mismatch"):
        report.aic_source_snapshot_details(tmp_path, "fixture", required=True)


def test_runtime_identity_checks_collector_against_all_real_groups(tmp_path):
    model = "Qwen3-0.6B"
    reference = tmp_path / "provenance/formal_start_after_ninja_fix/identity.json"
    reference.parent.mkdir(parents=True)
    reference.write_text("{}")
    (tmp_path / "run_metadata.txt").write_text("source_revision=test-sha\ntraining_real_repeats=1\nheldout_real_repeats=1\n")
    aic = tmp_path / "aic_calibration"
    (aic / "environment").mkdir(parents=True)
    (aic / "trace_targeted_run_metadata.txt").write_text("source_revision=test-sha\ncollector_triton_page_size=1\n")
    common = "torch=2.9.1+cu126\ntorch_cuda=12.6\nsgl_kernel_runtime_version=0.4.6.post1\nsgl_kernel_file=/tmp/fixture-native-stage/sgl_kernel/__init__.py\n"
    (aic / "environment/collector_runtime_versions.txt").write_text(common)
    for role in ("calibration", "holdout"):
        group = tmp_path / "models" / model / role / "real/repeat-1"
        group.mkdir(parents=True)
        (group / "run_metadata.txt").write_text("source_revision=test-sha\n")
        (group / "package_versions.txt").write_text(common + "python=3.10\nsglang=0.0.0\nsglang-kernel=0.4.6.post1+cu129\n")
    out = tmp_path / "report"
    out.mkdir()
    lines = report.runtime_identity_details(tmp_path, [model], out)
    assert any("0.4.6.post1+cu129" in line for line in lines)
    assert report.read_csv(out / "runtime_identity_checks.csv")[0]["recorded_real_groups"] == "2"
    version = tmp_path / "models" / model / "holdout/real/repeat-1/package_versions.txt"
    version.write_text(version.read_text().replace("2.9.1+cu126", "2.14+cpu"))
    with pytest.raises(ValueError, match="versions changed"):
        report.runtime_identity_details(tmp_path, [model], out)


def coverage_fixture(tmp_path):
    model, case = "Qwen3-0.6B", "latency_256x128_r1"
    def sample(mode, extend, past, latency=.01):
        return {"forward_mode": mode, "iter_latency": latency,
                "request_infos": [{"extend_input_len": extend, "prefix_indices_len": past}]}
    for role, values in (("calibration", [sample(1, 2, 0), sample(1, 4, 4), sample(2, 1, 1), sample(2, 1, 10), sample(1, 9999, 9999, 31)]),
                         ("holdout", [sample(1, 3, 2), sample(2, 1, 20)])):
        path = tmp_path / "models" / model / role / "real/repeat-1/cases" / case / "TP0.schedule_batch.jsonl"
        path.parent.mkdir(parents=True)
        path.write_text("".join(json.dumps(value) + "\n" for value in values))
    metrics = [{"model": model, "case": case, "phase": phase, "method": method, "n": str(2 if phase == "all" else 1), "mape_pct": "10"}
               for phase in ("all", "prefill", "decode") for method in ("ML", "AIC")]
    out = tmp_path / "coverage"
    out.mkdir()
    return model, case, metrics, out


def test_feature_coverage_matches_phases_and_training_filter(tmp_path):
    model, case, metrics, out = coverage_fixture(tmp_path)
    lines = report.workload_feature_coverage_details(tmp_path, [model], [case], metrics, out, Path("coverage"))
    rows = {row["phase"]: row for row in report.read_csv(out / "workload_feature_coverage.csv")}
    assert float(rows["all"]["outside_train_range_pct"]) == 50
    assert float(rows["prefill"]["outside_train_range_pct"]) == 0
    assert float(rows["decode"]["outside_train_range_pct"]) == 100
    assert int(rows["all"]["train_rows"]) == 4
    assert len(list(out.glob("*.png"))) == 4
    assert any("范围内不代表同分布" in line for line in lines)


def test_feature_coverage_rejects_different_scoring_counts(tmp_path):
    model, case, metrics, out = coverage_fixture(tmp_path)
    metrics[0]["n"] = "3"
    with pytest.raises(ValueError, match="batch counts differ"):
        report.workload_feature_coverage_details(tmp_path, [model], [case], metrics, out, Path("coverage"))


def test_historical_baselines_keep_real_values_and_metric_scopes(tmp_path):
    model = "Qwen2.5-3B-Instruct"
    current = tmp_path / "current"
    current.mkdir()
    out = current / "plots"
    out.mkdir()
    for name in ("pr33824_piecewise_a100_dense3_matrix_20260908_134523", "pr33824_a100_dense3_sm80compat_matrix_20260910_164000"):
        source = tmp_path / name
        source.mkdir()
        (source / "MATRIX_COMPLETE").write_text("complete\n")
        (source / "run_metadata.txt").write_text('source_revision=fixture\nreal_cuda_graph_config={"decode":"full"}\nreal_overlap_schedule_enabled=1\ntrace_policy=fixed seed\n')
        settings = source / "results" / model
        settings.mkdir(parents=True)
        (settings / "context-length.txt").write_text("8192\n")
        (settings / "real-mem-fraction-static.txt").write_text("0.80\n")
        rows = [{"model": model, "case": case, "complete_pairs": "5", "num_prompts": "32", "real_mean_e2e_latency_ms_mean": "100", "simulated_mean_e2e_latency_ms_mean": "120", "absolute_error_pct_mean_e2e_latency_ms_mean": "20"}
                for case in ("latency_256x128_r1", "service_1024x256_r4", "saturation_1024x256_inf")]
        write_csv(source / "analysis/case_metric_statistics.csv", rows)
        write_csv(source / "analysis/model_metric_statistics.csv", [{"model": model, "metric": metric, "paired_runs": "15", "mape_mean_pct": "20"} for metric in ("mean_e2e_latency_ms", "mean_ttft_ms")])
    lines = report.historical_aic_baseline_details(current, [model], out, Path("plots"))
    assert len(report.read_csv(out / "historical_aic_baselines.csv")) == 6
    assert any("100.00 | 120.00" in line for line in lines)
    assert any("不代表" in line or "不能" in line for line in lines)
    assert (out / "historical_aic_real_and_predicted.png").is_file()


def test_report_figures_and_simsun_docx(tmp_path, monkeypatch):
    model, case = fixture_results(tmp_path)
    bundle_dir = tmp_path / "models" / model / "calibration/training"
    bundle_dir.mkdir(parents=True)
    joblib.dump({"model": SimpleNamespace(n_iter_=20), "train_rows": 30, "train_cases": 15,
                 "best_params": {"random_state": 42}, "features": ["batch_size"],
                 "monotonic": [1], "max_latency_seconds": 30}, bundle_dir / f"{model}_hgbmono_p50.pkl")
    (tmp_path / "run_metadata.txt").write_text(f"models={model}\ntraining_case={case}\nheldout_case={case}\nheldout_real_repeats=5\n")
    markdown = tmp_path / "fixture.md"
    markdown.write_text("# Fixture, not experiment results\n")
    monkeypatch.setattr(sys, "argv", ["report", "--results-root", str(tmp_path), "--markdown", str(markdown), "--out-dir", str(tmp_path / "plots")])
    report.main()
    assert len(list((tmp_path / "plots").glob("*.png"))) == 5
    assert "tok/s" in markdown.read_text()
    assert "prefill 实测/预测" in markdown.read_text()
    assert "TTFT 实测 ± std / 预测" in markdown.read_text()
    assert "50%/50%、seed=42、forward_modes=1" in markdown.read_text()
    assert "9cfddcedc9d1e00885c28db75a45513eddbb6271" in markdown.read_text()
    assert "ElementWise" in markdown.read_text()
    assert "3 μs" in markdown.read_text()
    assert "解析项与本机实测表" in markdown.read_text()
    assert "QK norm" in markdown.read_text()
    assert "不是 GPU 实测时延" in markdown.read_text()
    assert "计时前调用 init_forward_metadata" in markdown.read_text()
    assert "不代表每个请求固定使用 8 个 split" in markdown.read_text()
    spec = importlib.util.spec_from_file_location("docx_renderer", ROOT / "scripts/render_markdown_report_docx.py")
    renderer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(renderer)
    output = tmp_path / "fixture.docx"
    renderer.render(markdown, output)
    from docx import Document
    from docx.oxml.ns import qn
    document = Document(output)
    assert len(document.inline_shapes) == 5
    fonts = document.element.xpath("//w:rFonts")
    assert fonts and all(node.get(qn("w:ascii")) == "SimSun" for node in fonts)
