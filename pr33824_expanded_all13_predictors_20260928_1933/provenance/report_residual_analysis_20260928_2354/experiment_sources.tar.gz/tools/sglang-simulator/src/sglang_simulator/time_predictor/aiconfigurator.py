import json
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional

import numpy as np
from aiconfigurator.sdk import common as aic_common
from aiconfigurator.sdk import models
from aiconfigurator.sdk.models import helpers as aic_model_helpers
from aiconfigurator.sdk.backends.factory import get_backend
from aiconfigurator.sdk.common import (
    CommQuantMode,
    DatabaseMode,
    FMHAQuantMode,
    GEMMQuantMode,
    KVCacheQuantMode,
    MoEQuantMode,
)
from aiconfigurator.sdk.config import ModelConfig, RuntimeConfig
from aiconfigurator.sdk.inference_session import InferenceSession
from aiconfigurator.sdk.perf_database import get_database, get_systems_paths
from sglang_simulator.simulation.types import (
    SchedulerConfig,
)
from sglang_simulator.spec.accelerator import AcceleratorInfo
from sglang_simulator.spec.data_type import DataType
from sglang_simulator.spec.model import ModelInfo
from sglang_simulator.time_predictor.base import (
    InferTimePredictor,
    ScheduleBatch,
    ScheduleRequest,
)
from sglang_simulator.utils import get_logger

# Map the common data types to AIConfigurator data types.
MAP_DTYPE_TO_GEMMQuantMode = {
    DataType.FP16: GEMMQuantMode.bfloat16,
    DataType.BF16: GEMMQuantMode.bfloat16,
    DataType.FP8: GEMMQuantMode.fp8_block,
    DataType.INT8: GEMMQuantMode.int8_wo,
    DataType.FP4: GEMMQuantMode.nvfp4,
    DataType.INT4: GEMMQuantMode.int4_wo,
    DataType.FP16_TENSOR: GEMMQuantMode.bfloat16,
    DataType.BF16_TENSOR: GEMMQuantMode.bfloat16,
    DataType.FP8_TENSOR: GEMMQuantMode.fp8,
    DataType.INT8_TENSOR: GEMMQuantMode.int8_wo,
    DataType.FP4_TENSOR: GEMMQuantMode.nvfp4,
    DataType.INT4_TENSOR: GEMMQuantMode.int4_wo,
}

MAP_DTYPE_TO_KVCacheQuantMode = {
    DataType.FP16: KVCacheQuantMode.bfloat16,
    DataType.BF16: KVCacheQuantMode.bfloat16,
    DataType.FP8: KVCacheQuantMode.fp8,
    DataType.INT8: KVCacheQuantMode.int8,
}

MAP_DTYPE_TO_FMHAQuantMode = {
    DataType.FP16: FMHAQuantMode.bfloat16,
    DataType.BF16: FMHAQuantMode.bfloat16,
    DataType.FP8: FMHAQuantMode.fp8,
}

MAP_DTYPE_TO_MoEQuantMode = {
    DataType.FP16: MoEQuantMode.bfloat16,
    DataType.BF16: MoEQuantMode.bfloat16,
    DataType.FP8: MoEQuantMode.fp8_block,
    DataType.INT8: MoEQuantMode.fp8,
    DataType.FP4: MoEQuantMode.nvfp4,
    DataType.INT4: MoEQuantMode.int4_wo,
}

MAP_DTYPE_TO_CommQuantMode = {
    DataType.FP16: CommQuantMode.half,
    DataType.BF16: CommQuantMode.half,
    DataType.FP8: CommQuantMode.fp8,
    DataType.INT8: CommQuantMode.int8,
}


logger = get_logger("sgl_simulator")


# AIConfigurator 0.10.0 does not list MistralForCausalLM in its public
# architecture map.  The dense Mistral checkpoint has the same decoder
# operator structure represented by AIC's LLAMA family, including GQA.
_AIC_ARCHITECTURE_ALIASES = {"MistralForCausalLM": "LLAMA"}
_AIC_SDK_PATCH_LOCK = threading.Lock()


def _register_aic_architecture_aliases() -> None:
    """Register known-compatible HuggingFace architectures missing from AIC."""
    architecture_map = aic_common.ARCHITECTURE_TO_MODEL_FAMILY
    for architecture, family in _AIC_ARCHITECTURE_ALIASES.items():
        registered_family = architecture_map.get(architecture)
        if registered_family is None:
            architecture_map[architecture] = family
            logger.info(
                "Registered AIConfigurator architecture compatibility alias: "
                "%s -> %s",
                architecture,
                family,
            )
        elif registered_family != family:
            logger.warning(
                "AIConfigurator architecture %s maps to %s, expected %s; "
                "using the SDK mapping.",
                architecture,
                registered_family,
                family,
            )


def _uses_awq_quantization(model_path: str) -> bool:
    """Return whether a local HuggingFace checkpoint declares AWQ weights."""
    config_path = Path(model_path) / "config.json"
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    quantization_config = config.get("quantization_config")
    return (
        isinstance(quantization_config, dict)
        and str(quantization_config.get("quant_method", "")).lower() == "awq"
    )


@contextmanager
def _aic_awq_bf16_compat(model_path: str) -> Iterator[None]:
    """Parse unsupported AWQ metadata with the configured BF16 operator mode.

    AIC 0.10 has no dense AWQ parser or SM80 AWQ GEMM table.  The experiment's
    70B AWQ row therefore preserves the real checkpoint topology while using
    BF16 operator data as an explicit proxy; it is never reported as native
    AWQ calibration.
    """
    if not _uses_awq_quantization(model_path):
        yield
        return

    original_infer = aic_model_helpers._infer_quant_modes_from_raw_config

    def infer_without_awq(raw_config: dict, architecture: Optional[str] = None):
        if raw_config.get("quant_algo") == "awq":
            raw_config = dict(raw_config)
            raw_config["quant_algo"] = None
        return original_infer(raw_config, architecture)

    with _AIC_SDK_PATCH_LOCK:
        logger.warning(
            "AIConfigurator 0.10 has no dense AWQ parser or SM80 AWQ GEMM "
            "table for %s; using the configured BF16 operator proxy. "
            "Do not treat this as AWQ-native calibration.",
            model_path,
        )
        aic_model_helpers._infer_quant_modes_from_raw_config = infer_without_awq
        try:
            yield
        finally:
            aic_model_helpers._infer_quant_modes_from_raw_config = original_infer


def _resolve_comm_quant_mode(sched_config: SchedulerConfig) -> CommQuantMode:
    if sched_config.comm_quant_mode_override:
        return getattr(CommQuantMode, sched_config.comm_quant_mode_override)

    if sched_config.data_type is None:
        return CommQuantMode.half

    try:
        return MAP_DTYPE_TO_CommQuantMode[sched_config.data_type]
    except KeyError:
        raise ValueError(
            "AIConfigurator has no communication quantization mapping for "
            f"model data type {sched_config.data_type.value}. Set "
            "comm_quant_mode_override explicitly to half, int8, or fp8."
        ) from None


def get_perf_model(
    sched_config: SchedulerConfig,
    model: ModelInfo,
    workload_distribution: str = "balanced",
) -> models.BaseModel:
    _register_aic_architecture_aliases()
    model_config = ModelConfig(
        pp_size=sched_config.pp_size,
        tp_size=sched_config.attn_tp_size,
        moe_tp_size=sched_config.moe_tp_size,
        moe_ep_size=sched_config.moe_ep_size,
        attention_dp_size=sched_config.attn_dp_size,
        cp_size=sched_config.cp_size,
        cp_style=sched_config.cp_style,
        gemm_quant_mode=MAP_DTYPE_TO_GEMMQuantMode.get(
            sched_config.data_type, GEMMQuantMode.bfloat16
        ),
        moe_quant_mode=(
            getattr(MoEQuantMode, sched_config.moe_quant_mode_override)
            if sched_config.moe_quant_mode_override
            else MAP_DTYPE_TO_MoEQuantMode.get(
                sched_config.data_type, MoEQuantMode.bfloat16
            )
        ),
        kvcache_quant_mode=MAP_DTYPE_TO_KVCacheQuantMode.get(
            sched_config.kv_cache_data_type, KVCacheQuantMode.bfloat16
        ),
        fmha_quant_mode=(
            getattr(FMHAQuantMode, sched_config.fmha_quant_mode_override)
            if sched_config.fmha_quant_mode_override
            else MAP_DTYPE_TO_FMHAQuantMode.get(
                sched_config.kv_cache_data_type, FMHAQuantMode.bfloat16
            )
        ),
        comm_quant_mode=_resolve_comm_quant_mode(sched_config),
        workload_distribution=workload_distribution,
    )

    logger.info(f"Model config for AIConfigurator: {model_config}")

    with _aic_awq_bf16_compat(model.model_path):
        return models.get_model(
            model_path=model.model_path,
            model_config=model_config,
            backend_name=sched_config.backend_name,
        )


class AIConfiguratorTimePredictor(InferTimePredictor):
    def __init__(
        self,
        model: ModelInfo,
        hw: AcceleratorInfo,
        config: SchedulerConfig,
        database_path: Optional[str] = None,
        database_mode: DatabaseMode | str = DatabaseMode.SILICON,
        prefill_scale_factor: float = 1,
        decode_scale_factor: float = 1,
        prefill_min_latency: float = 0,
        workload_distribution: str = "balanced",
        enable_oom_check: bool = False,
    ):
        super().__init__(model, hw, config)

        self.prefill_scale_factor = prefill_scale_factor
        self.decode_scale_factor = decode_scale_factor
        self.prefill_min_latency = prefill_min_latency
        if isinstance(database_mode, str):
            database_mode = self._get_database_mode(database_mode)

        database = get_database(
            system=hw.name,
            backend=config.backend_name,
            version=config.backend_version,
            systems_paths=(
                [database_path] if database_path is not None else get_systems_paths()
            ),
        )

        if database is None:
            raise ValueError("Failed to initialize the database.")

        database.set_default_database_mode(database_mode)
        logger.info(f"AIC Database mode: {database_mode}")

        self._session = InferenceSession(
            model=get_perf_model(config, model, workload_distribution),
            backend=get_backend(self.config.backend_name),
            database=database,
        )

        self.enable_oom_check = enable_oom_check
        self._is_oom = False

    def _get_database_mode(self, mode: str) -> DatabaseMode:
        return {
            "SILICON": DatabaseMode.SILICON,
            "HYBRID": DatabaseMode.HYBRID,
            "EMPIRICAL": DatabaseMode.EMPIRICAL,
            "SOL": DatabaseMode.SOL,
            "SOL_FULL": DatabaseMode.SOL_FULL,
        }.get(mode.upper(), DatabaseMode.SILICON)

    def ctx_attn_flops_ratio_with_avg(self, reqs: list[ScheduleRequest]) -> float:
        if len(reqs) == 1:
            return 1.0
        mean_past = np.mean([req.past_kv_length for req in reqs])
        mean_input = np.mean([req.extend_length for req in reqs])
        avg_flops = (mean_past + mean_past + mean_input) * mean_input / 2 * len(reqs)

        actual_flops = 0
        for req in reqs:
            actual_flops += (
                (req.past_kv_length + req.past_kv_length + req.extend_length)
                * req.extend_length
                / 2
            )

        return actual_flops / avg_flops

    def predict_infer_latency_dict(self, batch: ScheduleBatch) -> dict:
        # Returns latency details for debugging operators.
        if batch.is_decode():
            # Decode: output sequence length (osl) = 2, input sequence length (isl) = mean(past_kv_length)
            isl = int(np.mean([req.past_kv_length for req in batch.reqs]))
            runtime_config = RuntimeConfig(batch_size=batch.batch_size, isl=isl, osl=2)
            if self.enable_oom_check:
                summary = self._session.run_static(runtime_config, mode="static_gen")
                latency_dict = summary.get_generation_latency_dict()
            else:
                # faster path
                results = self._session._backend._run_static_breakdown(
                    self._session._model,
                    self._session._database,
                    runtime_config,
                    mode="static_gen",
                )
                latency_dict = results[2]
        else:
            # Prefill: output sequence length (osl) = 1, input sequence length (isl) = mean(past_kv + input), prefix = mean(past_kv)
            mean_past = np.mean([req.past_kv_length for req in batch.reqs])
            mean_input = np.mean([req.extend_length for req in batch.reqs])
            isl = int(mean_past + mean_input)
            prefix = int(mean_past)
            runtime_config = RuntimeConfig(
                batch_size=batch.batch_size, isl=isl, prefix=prefix, osl=1
            )

            seq_imbalance_correction_scale = self.ctx_attn_flops_ratio_with_avg(
                batch.reqs
            )
            if seq_imbalance_correction_scale >= 0.4:
                runtime_config = RuntimeConfig(
                    batch_size=batch.batch_size,
                    isl=isl,
                    prefix=prefix,
                    osl=1,
                    seq_imbalance_correction_scale=seq_imbalance_correction_scale,
                )
            else:
                runtime_config = RuntimeConfig(
                    batch_size=batch.batch_size, isl=isl, prefix=prefix, osl=1
                )

            if self.enable_oom_check:
                summary = self._session.run_static(runtime_config, mode="static_ctx")
                latency_dict = summary.get_context_latency_dict()
            else:
                # faster path
                results = self._session._backend._run_static_breakdown(
                    self._session._model,
                    self._session._database,
                    runtime_config,
                    mode="static_ctx",
                )
                latency_dict = results[0]
        return latency_dict

    def predict_infer_time(self, batch: ScheduleBatch) -> float:
        latency_dict = self.predict_infer_latency_dict(batch)
        infer_time = sum(latency_dict.values())

        if self._is_oom:
            logger.warning("Out of memory detected during estimation.")
            infer_time = -infer_time
        if batch.is_decode():
            infer_time *= self.decode_scale_factor
        else:
            infer_time *= self.prefill_scale_factor

        if not batch.is_decode():
            infer_time = (
                max(infer_time, self.prefill_min_latency)
                if infer_time > 0
                else infer_time
            )

        return infer_time / 1e3
