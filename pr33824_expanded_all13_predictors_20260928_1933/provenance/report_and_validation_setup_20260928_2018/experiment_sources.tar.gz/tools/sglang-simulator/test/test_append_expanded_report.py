"""Validate report completeness without launching servers or GPU workloads."""
from __future__ import annotations
import csv
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import joblib
import pytest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("expanded_report", ROOT / "tools/append_pr33824_expanded_report.py")
assert SPEC and SPEC.loader
report = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(report)


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def fixture_results(tmp_path, repeats=5):
    model = "Qwen3-0.6B"
    case = "latency_128x64_r1"
    model_root = tmp_path / "models" / model
    for method in ("ml", "aic"):
        batch = [{"group": group, "value": value, "n": "15", "mean_actual_ms": "2", "mean_predicted_ms": "1.8", "mape_pct": "10", "mae_ms": "0.2", "p95_ape_pct": "12", "mean_signed_error_pct": "-10"}
                 for group, value in (("case", case), ("case_forward_mode", case + ":mode1"), ("case_forward_mode", case + ":mode2"))]
        write_csv(model_root / "holdout" / f"{method}_teacher_forced" / "summary.csv", batch)
        pairs = [{"group": "case_metric", "value": case + ":" + metric, "n": str(repeats), "real_mean": "2", "real_std": "0.1", "predicted_mean": "1.8", "predicted_std": "0.1", "mape_pct": "10", "mean_signed_error_pct": "-10"}
                 for metric in ("mean_e2e_latency_ms", "mean_ttft_ms", "mean_tpot_ms", "total_throughput")]
        write_csv(model_root / "holdout" / f"{method}_e2e_comparison" / "summary.csv", pairs)
    write_csv(model_root / "learning_curve" / "learning_curve.csv", [{"model": model, "case": case, "training_traces": str(count), "phase": "all", "mape_pct": "10"} for count in (1, 3, 5)])
    return model, case


def test_report_has_batch_phases_and_all_metrics(tmp_path):
    model, case = fixture_results(tmp_path)
    batch, pairs, curves = report.collect(tmp_path, [model], [case], 5)
    assert len(batch) == 6
    assert len(pairs) == 8
    assert {row["phase"] for row in batch} == {"all", "prefill", "decode"}
    assert curves[0]["case"] == case


def test_report_rejects_incomplete_real_repeats(tmp_path):
    model, case = fixture_results(tmp_path, repeats=4)
    with pytest.raises(ValueError, match="wrong real repeat count"):
        report.collect(tmp_path, [model], [case], 5)


def test_previous_comparison_requires_identical_real_samples(tmp_path):
    model, case = fixture_results(tmp_path)
    for method in ("ml", "aic"):
        original = report.read_csv(tmp_path / "models" / model / "holdout" / f"{method}_teacher_forced/summary.csv")
        write_csv(tmp_path / "previous_calibration/models" / model / f"{method}_teacher_forced/summary.csv", original)
    rows = report.previous_calibration_rows(tmp_path, [model])
    assert len(rows) == 6 and all(row["improvement_pp"] == 0 for row in rows)
    original[0]["n"] = "14"
    write_csv(tmp_path / "previous_calibration/models" / model / "aic_teacher_forced/summary.csv", original)
    with pytest.raises(ValueError, match="different real observations"):
        report.previous_calibration_rows(tmp_path, [model])


def test_report_figures_and_simsun_docx(tmp_path, monkeypatch):
    model, case = fixture_results(tmp_path)
    bundle_dir = tmp_path / "models" / model / "calibration/training"
    bundle_dir.mkdir(parents=True)
    joblib.dump({"model": SimpleNamespace(n_iter_=20), "train_rows": 30, "train_cases": 15,
                 "best_params": {"random_state": 42}, "features": ["batch_size"],
                 "monotonic": [1], "max_latency_seconds": 30}, bundle_dir / f"{model}_hgbmono_p50.pkl")
    (tmp_path / "run_metadata.txt").write_text(f"models={model}\ntraining_case={case}\nheldout_case={case}\nheldout_real_repeats=5\n")
    markdown = tmp_path / "fixture.md"
    markdown.write_text("# Fixture, not experiment results\n")
    monkeypatch.setattr(sys, "argv", ["report", "--results-root", str(tmp_path), "--markdown", str(markdown), "--out-dir", str(tmp_path / "plots")])
    report.main()
    assert len(list((tmp_path / "plots").glob("*.png"))) == 5
    assert "tok/s" in markdown.read_text()
    spec = importlib.util.spec_from_file_location("docx_renderer", ROOT / "scripts/render_markdown_report_docx.py")
    renderer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(renderer)
    output = tmp_path / "fixture.docx"
    renderer.render(markdown, output)
    from docx import Document
    from docx.oxml.ns import qn
    document = Document(output)
    assert len(document.inline_shapes) == 5
    fonts = document.element.xpath("//w:rFonts")
    assert fonts and all(node.get(qn("w:ascii")) == "SimSun" for node in fonts)
