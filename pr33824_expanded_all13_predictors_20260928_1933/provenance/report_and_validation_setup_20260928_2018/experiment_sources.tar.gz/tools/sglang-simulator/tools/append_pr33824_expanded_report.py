#!/usr/bin/env python3
"""Append workload-separated tables, learning curves and measured/predicted plots."""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import time
from datetime import datetime
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as source:
        return list(csv.DictReader(source))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"empty result table: {path}")
    with path.open("x", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def collect(root: Path, models: list[str], cases: list[str], repeats: int) -> tuple[list[dict], list[dict], list[dict]]:
    batch, e2e, curves = [], [], []
    for model in models:
        model_root = root / "models" / model
        for method, path in (("ML", "ml"), ("AIC", "aic")):
            rows = read_csv(model_root / "holdout" / f"{path}_teacher_forced" / "summary.csv")
            if {row["value"] for row in rows if row["group"] == "case"} != set(cases):
                raise ValueError(f"missing or extra batch workloads for {model}/{method}")
            for row in rows:
                if row["group"] not in ("case", "case_forward_mode"):
                    continue
                case, phase = row["value"], "all"
                if row["group"] == "case_forward_mode":
                    case, mode = case.rsplit(":", 1)
                    phase = {"mode1": "prefill", "mode2": "decode"}[mode]
                batch.append({"model": model, "method": method, "case": case, "phase": phase,
                              **{key: row[key] for key in ("n", "mean_actual_ms", "mean_predicted_ms", "mape_pct", "mae_ms", "p95_ape_pct", "mean_signed_error_pct")}})
            paired = read_csv(model_root / "holdout" / f"{path}_e2e_comparison" / "summary.csv")
            expected = {(case, metric) for case in cases for metric in ("mean_e2e_latency_ms", "mean_ttft_ms", "mean_tpot_ms", "total_throughput")}
            actual = set()
            for row in paired:
                if row["group"] != "case_metric":
                    continue
                case, metric = row["value"].rsplit(":", 1)
                if int(row["n"]) != repeats:
                    raise ValueError(f"wrong real repeat count for {model}/{case}/{method}")
                actual.add((case, metric))
                e2e.append({"model": model, "method": method, "case": case, "metric": metric,
                            **{key: row[key] for key in ("n", "real_mean", "real_std", "predicted_mean", "predicted_std", "mape_pct", "mean_signed_error_pct")}})
            if actual != expected:
                raise ValueError(f"incomplete paired workloads for {model}/{method}")
        for row in read_csv(model_root / "learning_curve" / "learning_curve.csv"):
            curves.append(dict(row))
    return batch, e2e, curves


def previous_calibration_rows(root: Path, models: list[str]) -> list[dict]:
    """Pair old/new predictors only if actual batch counts and timings agree."""
    rows = []
    for model in models:
        for method in ("ml", "aic"):
            current = read_csv(root / "models" / model / "holdout" / f"{method}_teacher_forced/summary.csv")
            old = read_csv(root / "previous_calibration/models" / model / f"{method}_teacher_forced/summary.csv")
            previous = {(row["group"], row["value"]): row for row in old}
            for row in current:
                if row["group"] not in ("all", "forward_mode", "case", "case_forward_mode"):
                    continue
                matched = previous[(row["group"], row["value"])]
                if int(row["n"]) != int(matched["n"]) or not np.isclose(float(row["mean_actual_ms"]), float(matched["mean_actual_ms"]), rtol=1e-10):
                    raise ValueError(f"old/new score different real observations: {model}/{method}/{row['value']}")
                rows.append({"model": model, "method": method.upper(), "group": row["group"], "value": row["value"],
                             "n": int(row["n"]), "mean_actual_ms": float(row["mean_actual_ms"]),
                             "old_predicted_ms": float(matched["mean_predicted_ms"]), "new_predicted_ms": float(row["mean_predicted_ms"]),
                             "old_mape_pct": float(matched["mape_pct"]), "new_mape_pct": float(row["mape_pct"]),
                             "improvement_pp": float(matched["mape_pct"]) - float(row["mape_pct"]),
                             "old_mae_ms": float(matched["mae_ms"]), "new_mae_ms": float(row["mae_ms"]),
                             "old_p95_ape_pct": float(matched["p95_ape_pct"]), "new_p95_ape_pct": float(row["p95_ape_pct"])})
    return rows


def append_previous_comparison(root: Path, models: list[str], cases: list[str], out: Path, rel: Path) -> list[str]:
    rows = previous_calibration_rows(root, models)
    write_csv(out / "old_new_calibration_same_test.csv", rows)
    lines = ["## 固定新测试集的历史校准对照（仅单步）", "",
             "下面将 9 月 18 日的 ML bundle / AIC Silicon 表和本轮扩充结果评分于完全相同的本轮真实 batch；核对了每组样本数及实测均值。旧方法原有 E2E 不移入此表。ML 的训练负载覆盖和请求量同时改变，不能把改善全部归因于样本数量；前面的 160/480/800 请求曲线用于固定覆盖下的训练量检查。", "",
             "| 模型 | 方法 | 实测 ms | 旧预测 / 新预测 ms | 旧 MAPE / 新 MAPE | 改善（百分点） |",
             "| --- | --- | --- | --- | --- | --- |"]
    selected = [row for row in rows if row["group"] == "all"]
    for row in selected:
        lines.append(f"| {row['model']} | {row['method']} | {row['mean_actual_ms']:.2f} | {row['old_predicted_ms']:.2f} / {row['new_predicted_ms']:.2f} | {row['old_mape_pct']:.2f}% / {row['new_mape_pct']:.2f}% | {row['improvement_pp']:+.2f} |")
    fig, axes = plt.subplots(2, 1, figsize=(14, 10))
    for ax, method in zip(axes, ("ML", "AIC")):
        subset = {row["model"]: row for row in selected if row["method"] == method}
        x = np.arange(len(models))
        ax.bar(x - .18, [subset[m]["old_mape_pct"] for m in models], .36, label="Previous calibration")
        ax.bar(x + .18, [subset[m]["new_mape_pct"] for m in models], .36, label="Expanded calibration")
        ax.set_xticks(x, models, rotation=30, ha="right", fontsize=8)
        ax.set_title(f"{method}: old/new calibration on identical new real batches")
        ax.set_ylabel("Batch MAPE (%)")
        ax.legend()
        ax.grid(axis="y", alpha=.2)
    fig.tight_layout()
    fig.savefig(out / "old_new_calibration_mape.png", dpi=180)
    plt.close(fig)
    lines.extend(["", f"![固定新测试集的校准对照]({rel / 'old_new_calibration_mape.png'})", ""])
    for method in ("ML", "AIC"):
        subset = {(row["model"], row["value"]): row for row in rows if row["method"] == method and row["group"] == "case"}
        values = np.asarray([[subset[(model, case)]["improvement_pp"] for case in cases] for model in models])
        limit = max(1., float(np.max(np.abs(values))))
        fig, ax = plt.subplots(figsize=(9, max(5, len(models) * .38)))
        picture = ax.imshow(values, cmap="RdYlGn", vmin=-limit, vmax=limit, aspect="auto")
        ax.set_xticks(range(len(cases)), cases, rotation=25, ha="right", fontsize=8)
        ax.set_yticks(range(len(models)), models, fontsize=8)
        for i in range(len(models)):
            for j in range(len(cases)):
                ax.text(j, i, f"{values[i,j]:+.1f}", ha="center", va="center", fontsize=8)
        ax.set_title(f"{method}: old MAPE - new MAPE (percentage points)")
        fig.colorbar(picture, ax=ax, label="Positive = lower error after expanded calibration")
        fig.tight_layout()
        filename = f"{method.lower()}_old_new_calibration_workloads.png"
        fig.savefig(out / filename, dpi=180)
        plt.close(fig)
        lines.extend([f"![{method} 分负载校准差值]({rel / filename})", ""])
    return lines


def wait_previous_comparison(root: Path) -> bool:
    previous = root / "previous_calibration"
    if not (previous / "reference.json").is_file():
        return False
    while not (previous / "PREVIOUS_CALIBRATION_COMPLETE").is_file():
        if (previous / "COMPARISON_FAILED").is_file():
            raise RuntimeError((previous / "COMPARISON_FAILED").read_text())
        owner = json.loads((previous / "owner.json").read_text())
        proc = Path(f"/proc/{int(owner['pid'])}/cmdline")
        if not proc.exists() or b"run_pr33824_previous_calibration_comparison.py" not in proc.read_bytes():
            raise RuntimeError("historical calibration scorer is not running; resume it before report generation")
        print("Waiting for historical calibration scoring; recheck in 600 seconds", flush=True)
        time.sleep(600)
    return True


def training_details(root: Path, models: list[str], out: Path) -> list[str]:
    import joblib
    rows = []
    for model in models:
        bundle = joblib.load(root / "models" / model / "calibration/training" / f"{model}_hgbmono_p50.pkl")
        rows.append({"model": model, "fit_input_rows": bundle["train_rows"], "training_cases": bundle["train_cases"],
                     "actual_iterations": int(bundle["model"].n_iter_),
                     "parameters": json.dumps(bundle["best_params"], ensure_ascii=False),
                     "features": json.dumps(bundle["features"], ensure_ascii=False),
                     "monotonic_constraints": json.dumps(bundle["monotonic"], ensure_ascii=False),
                     "max_training_latency_seconds": bundle["max_latency_seconds"]})
    write_csv(out / "training_parameters.csv", rows)
    lines = ["## ML 训练记录", "",
             "正式 predictor 为每模型独立 HGB p50，18 维 batch/长度特征；不按独立测试误差选择 p50 或 L2。训练集合内先按每条 trace 用例随机划分 80%/20%作内部检查，再将全部训练行传给最终 fit；HGB 另取训练侧 15%作 early-stopping 验证，不使用正式测试请求。", "",
             "| 参数 | 设置 |", "| --- | --- |",
             "| loss / quantile | quantile / 0.5 |", "| max_iter / max_leaf_nodes | 400 / 63 |",
             "| learning_rate / l2_regularization | 0.04 / 0.1 |",
             "| early_stopping / validation_fraction / n_iter_no_change | True / 0.15 / 20 |",
             "| 标签与过滤 | iter_latency，秒；训练只保留有效 mode=1/2、非空 batch、0 < latency ≤ 30 秒；正式评分保留所有有限正时延 |", "",
             "| 模型 | 最终 fit 输入行 | 训练 trace 用例 | 实际迭代数 |", "| --- | --- | --- | --- |"]
    for row in rows:
        lines.append(f"| {row['model']} | {row['fit_input_rows']} | {row['training_cases']} | {row['actual_iterations']} |")
    lines.extend(["", "全部特征名称、单调约束、random_state 和实际参数另存 training_parameters.csv；原始 bundle 和训练命令同时保留。", ""])
    return lines


def telemetry_details(root: Path, models: list[str], out: Path) -> list[str]:
    log = root / "hardware/gpu_telemetry.jsonl"
    if not log.is_file():
        return ["## GPU 状态记录", "", "本轮没有连续 GPU 遥测文件；启动快照不足以排除运行期间干扰。", ""]
    samples = [json.loads(line) for line in log.read_text().splitlines() if line.strip()]
    rows = []
    zone = datetime.now().astimezone().tzinfo
    pattern = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\]")
    for model in models:
        model_root = root / "models" / model
        for role, folder in (("training", "calibration"), ("holdout", "holdout")):
            for server_log in model_root.glob(f"{folder}/real/repeat-*/cases/*.server.log"):
                starts, ends, compilations = [], [], []
                for line in server_log.read_text().splitlines():
                    match = pattern.match(line)
                    if not match:
                        continue
                    stamp = datetime.strptime(match[1], "%Y-%m-%d %H:%M:%S").replace(tzinfo=zone).timestamp()
                    if '"POST /start_profile HTTP' in line:
                        starts.append(stamp)
                    if '"POST /stop_profile HTTP' in line:
                        ends.append(stamp)
                    if "compile after serving started" in line:
                        compilations.append(stamp)
                if len(starts) != 1 or len(ends) != 1:
                    raise ValueError(f"expected exactly one successful profiling window: {server_log}")
                window = [sample for sample in samples if starts[0] <= sample["wall_time"] <= ends[0] and "gpu" in sample]
                others = [sample for sample in window if any(not process["own_real_collector"] for process in sample.get("processes", []))]
                rows.append({"model": model, "role": role, "repeat": server_log.parents[1].name,
                             "case": server_log.name.removesuffix(".server.log"),
                             "telemetry_samples": len(window), "samples_with_other_resident_processes": len(others),
                             "profile_logged_slow_compilations": sum(starts[0] <= stamp <= ends[0] for stamp in compilations),
                             "profile_start_wall_time": starts[0], "profile_end_wall_time": ends[0]})
    if rows:
        write_csv(out / "gpu_collection_windows.csv", rows)
    lines = ["## GPU 状态与采集质量", "",
             "每次服务启动前记录显存和驻留进程，另每 30 秒采样一次 GPU 功率、频率、温度和进程。下表只统计真实 profile 时间窗；未采到的窗口记为未覆盖，不当作没有干扰。其他进程驻留不等同于同时执行计算，30 秒采样也不能排除短时干扰。", "",
             "| 模型 | 真实用例总数 | 遥测覆盖用例 | 采到其他驻留进程的用例 | profile 内日志记录的慢编译 |",
             "| --- | --- | --- | --- | --- |"]
    for model in models:
        subset = [row for row in rows if row["model"] == model]
        lines.append(f"| {model} | {len(subset)} | {sum(row['telemetry_samples'] > 0 for row in subset)} | {sum(row['samples_with_other_resident_processes'] > 0 for row in subset)} | {sum(row['profile_logged_slow_compilations'] for row in subset)} |")
    return lines + ["", "原始遥测和每用例统计均保留；日志慢编译统计不是所有编译事件的完整计数，不据此自动删去较慢样本。", ""]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    metadata = dict(line.split("=", 1) for line in (args.results_root / "run_metadata.txt").read_text().splitlines() if "=" in line)
    models = metadata["models"].split(",")
    train_cases = metadata["training_case"].split(",")
    cases = metadata["heldout_case"].split(",")
    include_previous = wait_previous_comparison(args.results_root)
    batch, e2e, curves = collect(args.results_root, models, cases, int(metadata["heldout_real_repeats"]))
    args.out_dir.mkdir(parents=True, exist_ok=False)
    write_csv(args.out_dir / "workload_batch_metrics.csv", batch)
    write_csv(args.out_dir / "workload_end_to_end_metrics.csv", e2e)
    write_csv(args.out_dir / "learning_curves.csv", curves)
    lines = ["", "## 同负载与跨负载测试", "",
             "前三类负载出现在训练数据中，但测试请求和 seed 独立；后两类负载不用于训练。跨负载不代表所有特征都在训练范围之外。以下按模型与负载列出实测值和预测值，避免把五类负载混成一个精度结论。", ""]
    rel = Path(os.path.relpath(args.out_dir, args.markdown.parent))
    lines = training_details(args.results_root, models, args.out_dir) + lines
    for case in cases:
        label = "同负载独立测试" if case in train_cases else "跨负载测试"
        lines.extend([f"### {case}（{label}）", "",
                      "| 模型 | 方法 | 单步实测/预测 ms | 单步 MAPE / MAE ms | E2E 实测 ± std / 预测 ms | E2E MAPE | TTFT MAPE | TPOT MAPE | 总 token 吞吐实测/预测 tok/s |",
                      "| --- | --- | --- | --- | --- | --- | --- | --- | --- |"])
        for model in models:
            for method in ("ML", "AIC"):
                b = next(row for row in batch if row["model"] == model and row["method"] == method and row["case"] == case and row["phase"] == "all")
                metrics = {row["metric"]: row for row in e2e if row["model"] == model and row["method"] == method and row["case"] == case}
                r = metrics["mean_e2e_latency_ms"]
                t = metrics["total_throughput"]
                f = lambda row, key: float(row[key])
                lines.append(f"| {model} | {method} | {f(b,'mean_actual_ms'):.2f} / {f(b,'mean_predicted_ms'):.2f} | {f(b,'mape_pct'):.2f}% / {f(b,'mae_ms'):.2f} | {f(r,'real_mean'):.2f} ± {f(r,'real_std'):.2f} / {f(r,'predicted_mean'):.2f} | {f(r,'mape_pct'):.2f}% | {f(metrics['mean_ttft_ms'],'mape_pct'):.2f}% | {f(metrics['mean_tpot_ms'],'mape_pct'):.2f}% | {f(t,'real_mean'):.2f} / {f(t,'predicted_mean'):.2f} |")
        lines.append("")
    for method in ("ML", "AIC"):
        for category in ("batch", "e2e"):
            rows = batch if category == "batch" else e2e
            selected = [row for row in rows if row["method"] == method and row.get("phase", "all") == "all" and row.get("metric", "mean_e2e_latency_ms") == "mean_e2e_latency_ms"]
            values = np.asarray([[float(next(row["mape_pct"] for row in selected if row["model"] == model and row["case"] == case)) for case in cases] for model in models])
            fig, ax = plt.subplots(figsize=(9, max(5, len(models) * .38)))
            picture = ax.imshow(values, aspect="auto", cmap="YlOrRd", vmin=0)
            ax.set_xticks(range(len(cases)), cases, rotation=25, ha="right", fontsize=8)
            ax.set_yticks(range(len(models)), models, fontsize=8)
            for i in range(len(models)):
                for j in range(len(cases)):
                    ax.text(j, i, f"{values[i,j]:.1f}", ha="center", va="center", fontsize=8)
            ax.set_title(f"{method}: {category} MAPE (%) by workload")
            fig.colorbar(picture, ax=ax, label="MAPE (%)")
            fig.tight_layout()
            filename = f"{method.lower()}_{category}_workload_heatmap.png"
            fig.savefig(args.out_dir / filename, dpi=180)
            plt.close(fig)
            lines.extend([f"![{method} {category} 分负载误差]({rel / filename})", ""])
    requests_per_group = int(metadata.get("requests_per_training_repeat", "160"))
    lines.extend(["## 训练量递增对比", "", f"测试集保持不变，以前 1、3、5 组训练 trace 分别拟合，训练请求数为 {requests_per_group}、{requests_per_group * 3}、{requests_per_group * 5}；下面曲线按负载展示。增加样本是否有效以实测误差变化为准，不预设单调改善。", ""])
    labels = {"latency_256x128_r1": "256/128 @1/s", "service_1024x256_r4": "1024/256 @4/s",
              "saturation_1024x256_inf": "1024/256 burst", "latency_128x64_r1": "128/64 @1/s",
              "saturation_1536x384_inf": "1536/384 burst"}
    for offset in range(0, len(models), 4):
        group = models[offset:offset + 4]
        single = len(group) == 1
        fig, axes = plt.subplots(1 if single else 2, 1 if single else 2, figsize=(7, 4.5) if single else (10, 7), squeeze=False)
        for ax, model in zip(axes.flat, group):
            for case in cases:
                rows = sorted([row for row in curves if row["model"] == model and row.get("case") == case], key=lambda row: int(row["training_traces"]))
                if len(rows) != 3:
                    raise ValueError(f"incomplete per-workload learning curve: {model}/{case}")
                ax.plot([int(row["training_traces"]) * requests_per_group for row in rows], [float(row["mape_pct"]) for row in rows], marker="o", label=labels.get(case, case))
            ax.set_title(model, fontsize=11)
            ax.set_xlabel("Training requests", fontsize=10)
            ax.set_ylabel("Batch MAPE (%)", fontsize=10)
            ax.grid(alpha=.25)
        for ax in list(axes.flat)[len(group):]:
            ax.set_visible(False)
        handles, legend_labels = axes.flat[0].get_legend_handles_labels()
        fig.legend(handles, legend_labels, loc="lower center", ncol=3, fontsize=10)
        fig.tight_layout(rect=(0, .1, 1, 1))
        filename = f"learning_curves_models_{offset + 1}_{offset + len(group)}.png"
        fig.savefig(args.out_dir / filename, dpi=180)
        plt.close(fig)
        lines.extend([f"![模型 {offset + 1}–{offset + len(group)} 训练量曲线]({rel / filename})", ""])
    lines.extend([
                  "完整 prefill/decode、P95 APE、偏差与样本数见同目录 workload_batch_metrics.csv；全部 E2E、TTFT、TPOT、吞吐及实机标准差见 workload_end_to_end_metrics.csv。", "",
                  "## 结果解释的边界", "",
                  "同步墙钟单步时延包含 run_batch 内 CPU 发射、采样/拷贝和同步等待，AIC 算子 GPU 时延求和不包含全部这些开销。因此增加 AIC 算子点与提高端到端准确性不是同一件事。AWQ BF16 代理、dual-chunk attention 代理与 MoE 路由覆盖限制沿用前文单列说明。当前 GPU 其他进程及显存状态已记录；本轮不是无干扰的硬件性能标定。", ""])
    if include_previous:
        lines.extend(append_previous_comparison(args.results_root, models, cases, args.out_dir, rel))
    lines.extend(telemetry_details(args.results_root, models, args.out_dir))
    args.markdown.write_text(args.markdown.read_text(encoding="utf-8") + "\n".join(lines), encoding="utf-8")
    print(f"workload batch rows={len(batch)} e2e rows={len(e2e)} curve rows={len(curves)}")


if __name__ == "__main__":
    main()
