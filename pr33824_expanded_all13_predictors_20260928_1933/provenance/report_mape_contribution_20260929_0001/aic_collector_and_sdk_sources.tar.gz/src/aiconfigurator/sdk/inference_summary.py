# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import logging

import pandas as pd

from aiconfigurator.sdk.config import RuntimeConfig

logger = logging.getLogger(__name__)


class InferenceSummary:
    """
    InferecneSummary to hold results of inference with energy tracking.

    Attributes:
        runtime_config: runtime config
        memory: memory breakdown
        context_latency_dict: latency breakdown for context (ms)
        generation_latency_dict: latency breakdown for generation (ms)
        context_energy_wms_dict: energy breakdown for context (W·ms)
        generation_energy_wms_dict: energy breakdown for generation (W·ms)
        summary_df: summary dataframe

    Units:
        - latency: milliseconds (ms)
        - energy: watt-milliseconds (W·ms) = millijoules (mJ)
        - power: watts (W) - derived from energy/latency

    Methods:
        set_memory_and_check_oom: set memory and check oom (+ optional kv cache budget check)
        set_oom: set oom
        check_oom: check oom
        set_kv_cache_oom: set kv cache oom
        check_kv_cache_oom: check kv cache oom
        set_context_latency_dict: set context latency dict
        set_generation_latency_dict: set generation latency dict
        get_context_latency_dict: get context latency dict
        get_generation_latency_dict: get generation latency dict
        set_context_energy_wms_dict: set context energy dict
        set_generation_energy_wms_dict: set generation energy dict
        get_context_energy_wms_dict: get context energy dict
        get_generation_energy_wms_dict: get generation energy dict
        set_kv_per_seq: stash per-sequence KV cache footprint context (for capacity probing)
        get_kv_per_seq: get per-sequence KV cache footprint context
        get_mem_capacity_bytes: get the GPU memory capacity captured by set_memory_and_check_oom
        get_static_info: legacy static breakdown text (returns 5 values)
        set_summary_df: set summary dataframe
        get_summary_df: get summary dataframe
    """

    def __init__(self, runtime_config: RuntimeConfig) -> None:
        """
        Initialize inference summary.
        """
        self._runtime_config = runtime_config

        # raw data dict
        self._memory = {}
        self._encoder_memory = {}  # colocated encoder memory component breakdown (VL models only)
        self._encoder_latency_dict = {}  # ms
        self._context_latency_dict = {}  # ms
        self._generation_latency_dict = {}  # ms
        self._encoder_energy_wms_dict = {}  # W·ms
        self._context_energy_wms_dict = {}  # RENAMED from _context_power_dict, W·ms
        self._generation_energy_wms_dict = {}  # RENAMED from _generation_power_dict, W·ms
        # Per-op data source ("silicon", "empirical", "sol", or "mixed") populated by
        # base_backend phase helpers from PerformanceResult.source.
        self._encoder_source_dict: dict[str, str] = {}
        self._context_source_dict: dict[str, str] = {}
        self._generation_source_dict: dict[str, str] = {}
        self._is_oom = None
        self._is_kv_cache_oom = False

        # NEW: Store computed power averages
        self._encoder_power_avg = 0.0
        self._context_power_avg = 0.0
        self._generation_power_avg = 0.0
        self._e2e_power_avg = 0.0

        # summary dataframe
        self._summary_df = None

        # cached result dict for efficient batch operations
        self._result_dict = None

        # per-ops latency breakdown (populated by run_agg or run_disagg)
        self._per_ops_data: dict | None = None
        # per-ops data source breakdown, parallel to _per_ops_data: same key
        # structure but values are "silicon" / "empirical" / "sol" / "mixed" strings.
        self._per_ops_source: dict | None = None

        # Capacity probing context. Populated by set_memory_and_check_oom
        # (capacity) and by backends running static-mode estimation (kv per seq).
        # Used by CLI detail reports to compute capacity-% / headroom /
        # max-batch-size estimates.
        self._mem_capacity_bytes: int | None = None
        self._free_gpu_memory_fraction: float | None = None
        self._kv_cache_reserved_fraction: float = 0.0
        self._kv_cache_tolerance: float = 0.0
        self._kv_bytes_per_seq: float | None = None
        self._kv_seq_len_used: int | None = None

    def set_memory_and_check_oom(
        self,
        memory_dict: dict,
        mem_capacity: int,
        free_gpu_memory_fraction: float | None = None,
        kv_cache_reserved_fraction: float = 0.0,
        kv_cache_tolerance: float = 0.0,
    ) -> None:
        """
        Set memory and check oom.

        *memory_dict* should reflect the actual runtime memory layout
        (e.g. kvcache computed with ``max_seq_len``, activations with
        ``max_num_tokens``).

        When *free_gpu_memory_fraction* is not ``None``, also performs the
        KV cache budget check using the same *memory_dict*.
        """
        self._memory = memory_dict
        self._is_oom = self._memory["total"] >= (mem_capacity / (1 << 30))
        self._is_kv_cache_oom = False
        self._mem_capacity_bytes = mem_capacity
        self._free_gpu_memory_fraction = free_gpu_memory_fraction
        self._kv_cache_reserved_fraction = kv_cache_reserved_fraction
        self._kv_cache_tolerance = kv_cache_tolerance
        if free_gpu_memory_fraction is not None:
            self._check_and_set_kv_cache_oom(
                mem_capacity,
                free_gpu_memory_fraction,
                kv_cache_reserved_fraction,
                kv_cache_tolerance,
            )

    def _check_and_set_kv_cache_oom(
        self,
        mem_capacity: int,
        free_gpu_memory_fraction: float,
        kv_cache_reserved_fraction: float,
        kv_cache_tolerance: float,
    ) -> None:
        """Check whether the KV cache exceeds the fraction-based memory budget.

        Uses ``self._memory`` (set by :meth:`set_memory_and_check_oom`).

        Equivalent to the inflation formula
        ``kv / (frac*(1-res)*(1-tol)) + non_kv >= capacity`` rewritten as
        ``kv > (capacity - non_kv) * frac * (1-res) * (1-tol)``.
        """
        self._is_kv_cache_oom = False
        if self._is_oom:
            return
        mem_cap_gib = mem_capacity / (1 << 30)
        kv_gib = self._memory.get("kvcache", 0.0)
        non_kv_gib = self._memory["total"] - kv_gib
        kv_budget = (
            (mem_cap_gib - non_kv_gib)
            * free_gpu_memory_fraction
            * (1 - kv_cache_reserved_fraction)
            * (1 - kv_cache_tolerance)
        )
        self._is_kv_cache_oom = kv_gib > kv_budget

    def set_encoder_memory(self, memory_dict: dict) -> None:
        """Set colocated encoder memory component breakdown (VL models only)."""
        self._encoder_memory = memory_dict

    def get_encoder_memory(self) -> dict:
        """Get colocated encoder memory component breakdown. Empty dict for text-only models."""
        return self._encoder_memory

    def set_oom(self, is_oom: bool) -> None:
        """
        Set oom.
        """
        self._is_oom = is_oom

    def set_encoder_latency_dict(self, encoder_latency_dict: dict) -> None:
        """
        Set encoder latency dict.
        """
        self._encoder_latency_dict = encoder_latency_dict

    def set_context_latency_dict(self, context_latency_dict: dict) -> None:
        """
        Set context latency dict.
        """
        self._context_latency_dict = context_latency_dict

    def set_generation_latency_dict(self, generation_latency_dict: dict) -> None:
        """
        Set generation latency dict.
        """
        self._generation_latency_dict = generation_latency_dict

    def get_encoder_latency_dict(self) -> dict:
        """
        Get encoder latency dict.
        """
        return self._encoder_latency_dict

    def get_context_latency_dict(self) -> dict:
        """
        Get context latency dict.
        """
        return self._context_latency_dict

    def get_generation_latency_dict(self) -> dict:
        """
        Get generation latency dict.
        """
        return self._generation_latency_dict

    # NEW: Energy dict accessors (explicit _wms naming for clarity)
    def set_encoder_energy_wms_dict(self, energy_wms_dict: dict[str, float]) -> None:
        """
        Set encoder energy dict (units: W·ms).

        Args:
            energy_wms_dict: Dict of operation -> energy in watt-milliseconds (W·ms).
                            Note: 1 W·ms = 1 millijoule (mJ).
        """
        self._encoder_energy_wms_dict = energy_wms_dict

    def set_context_energy_wms_dict(self, energy_wms_dict: dict[str, float]) -> None:
        """
        Set context energy dict (units: W·ms).

        Args:
            energy_wms_dict: Dict of operation -> energy in watt-milliseconds (W·ms).
                            Note: 1 W·ms = 1 millijoule (mJ).
        """
        self._context_energy_wms_dict = energy_wms_dict

    def set_generation_energy_wms_dict(self, energy_wms_dict: dict[str, float]) -> None:
        """
        Set generation energy dict (units: W·ms).

        Args:
            energy_wms_dict: Dict of operation -> energy in watt-milliseconds (W·ms).
        """
        self._generation_energy_wms_dict = energy_wms_dict

    def get_encoder_energy_wms_dict(self) -> dict[str, float]:
        """
        Returns dict of operation -> energy in watt-milliseconds (W·ms).

        Note: 1 W·ms = 1 millijoule (mJ). To convert to joules: divide by 1000.
        """
        return self._encoder_energy_wms_dict

    def get_context_energy_wms_dict(self) -> dict[str, float]:
        """
        Returns dict of operation -> energy in watt-milliseconds (W·ms).

        Note: 1 W·ms = 1 millijoule (mJ). To convert to joules: divide by 1000.
        """
        return self._context_energy_wms_dict

    def get_generation_energy_wms_dict(self) -> dict[str, float]:
        """
        Returns dict of operation -> energy in watt-milliseconds (W·ms).
        """
        return self._generation_energy_wms_dict

    # Alias accessors (for less verbose code)
    def get_encoder_energy_dict(self) -> dict[str, float]:
        """Alias for get_encoder_energy_wms_dict() - returns energy in W·ms"""
        return self._encoder_energy_wms_dict

    def get_context_energy_dict(self) -> dict[str, float]:
        """Alias for get_context_energy_wms_dict() - returns energy in W·ms"""
        return self._context_energy_wms_dict

    def get_generation_energy_dict(self) -> dict[str, float]:
        """Alias for get_generation_energy_wms_dict() - returns energy in W·ms"""
        return self._generation_energy_wms_dict

    # NEW: Power average accessors
    def set_encoder_power_avg(self, power_avg: float) -> None:
        """Set encoder phase average power (watts)."""
        self._encoder_power_avg = power_avg

    def set_context_power_avg(self, power_avg: float) -> None:
        """Set context phase average power (watts)."""
        self._context_power_avg = power_avg

    def set_generation_power_avg(self, power_avg: float) -> None:
        """Set generation phase average power (watts)."""
        self._generation_power_avg = power_avg

    def set_e2e_power_avg(self, power_avg: float) -> None:
        """Set end-to-end average power (watts)."""
        self._e2e_power_avg = power_avg

    def get_encoder_power_avg(self) -> float:
        """Get encoder phase average power (watts)."""
        return self._encoder_power_avg

    def get_context_power_avg(self) -> float:
        """Get context phase average power (watts)."""
        return self._context_power_avg

    def get_generation_power_avg(self) -> float:
        """Get generation phase average power (watts)."""
        return self._generation_power_avg

    def get_e2e_power_avg(self) -> float:
        """Get end-to-end average power (watts)."""
        return self._e2e_power_avg

    def has_sufficient_power_data(self, threshold: float = 0.9) -> bool:
        """
        Check if power data coverage is sufficient for reliable power estimation.

        Args:
            threshold: Minimum ratio of latency with non-zero energy to total latency (default 0.9)

        Returns:
            bool: True if latency with non-zero energy >= threshold * total latency
        """
        # Calculate total latency
        total_latency = (
            sum(self._encoder_latency_dict.values())
            + sum(self._context_latency_dict.values())
            + sum(self._generation_latency_dict.values())
        )

        if total_latency == 0:
            return False

        # Calculate latency from operations with non-zero energy
        latency_with_energy = 0.0
        for op_name, latency in self._encoder_latency_dict.items():
            if self._encoder_energy_wms_dict.get(op_name, 0.0) > 0:
                latency_with_energy += latency

        for op_name, latency in self._context_latency_dict.items():
            if self._context_energy_wms_dict.get(op_name, 0.0) > 0:
                latency_with_energy += latency

        for op_name, latency in self._generation_latency_dict.items():
            if self._generation_energy_wms_dict.get(op_name, 0.0) > 0:
                latency_with_energy += latency

        # Check if coverage meets threshold
        coverage_ratio = latency_with_energy / total_latency
        return coverage_ratio >= threshold

    def check_oom(self) -> bool:
        """
        Check if total memory usage exceeds GPU capacity.

        Returns True when ``weights + activations + kvcache + overhead >=
        gpu_capacity``.  This is the *absolute* capacity check.

        A separate :meth:`check_kv_cache_oom` exists for the *relative*
        budget check, i.e. whether the KV cache portion alone exceeds the
        ``free_gpu_memory_fraction``-based budget that the serving runtime
        reserves for KV cache.
        """
        if self._is_oom is None:
            logger.warning("WARNING: memory status is not set")
        return self._is_oom

    def set_kv_cache_oom(self, is_kv_cache_oom: bool) -> None:
        """
        Set kv cache oom.
        """
        self._is_kv_cache_oom = is_kv_cache_oom

    def check_kv_cache_oom(self) -> bool:
        """
        Check kv cache oom.
        """
        return self._is_kv_cache_oom

    def get_memory(self) -> dict:
        """
        Get memory breakdown dict (keys: total, weights, activations, kvcache, nccl, others).
        """
        return self._memory

    def get_static_info(self) -> tuple[str, str, str, str, str]:
        """
        Get static info.
        """

        def get_latency_and_breakdown_percentage_string_helper(metrics: dict) -> tuple[float, str]:
            breakdown_string = ""
            latency = 0
            for op, op_latency in metrics.items():
                latency += op_latency

            breakdown_string += f"total                      ({latency:>10.5f} ms)\n"
            for op, op_latency in metrics.items():
                breakdown_string += f"{op:<25}   {op_latency:>10.3f} ms {int(op_latency / latency * 100):>5}%\n"
            return latency, breakdown_string

        encoder_latency, encoder_latency_string = get_latency_and_breakdown_percentage_string_helper(
            self._encoder_latency_dict
        )
        context_latency, context_latency_string = get_latency_and_breakdown_percentage_string_helper(
            self._context_latency_dict
        )
        generation_latency, generation_latency_string = get_latency_and_breakdown_percentage_string_helper(
            self._generation_latency_dict
        )

        assert self._summary_df is not None, "summary df is not set"

        # summary string for display
        perf_info = "Performance Summary:\n"
        perf_info += f"total latency        {(encoder_latency + context_latency + generation_latency):>17.5f} ms\n"
        if encoder_latency != 0:
            perf_info += f"encoder latency:{encoder_latency:>19.5f} ms\n"
        perf_info += f"context latency (ttft):{context_latency:>16.5f} ms\n"
        if generation_latency != 0:
            perf_info += f"generation latency:{generation_latency:>19.5f} ms\n"
            perf_info += (
                f"throughput {self._summary_df.loc[0, 'tokens/s']:.2f} tokens/s, tpot "
                f"{self._summary_df.loc[0, 'tpot']:.3f} ms\n"
            )
        encoder_info = "Encoder breakdown:\n" + encoder_latency_string if encoder_latency != 0 else ""
        context_info = "Context breakdown:\n" + context_latency_string
        generation_info = "Generation breakdown:\n" + generation_latency_string

        mem_info = "\nMemory Usage: \n"
        for item, memory_usage in self._memory.items():
            mem_info += f"{item:29} {memory_usage:>8.3f} GiB\n"

        return perf_info, mem_info, encoder_info, context_info, generation_info

    def set_summary_df(self, summary_df: pd.DataFrame) -> None:
        """
        Set summary dataframe.
        """
        self._summary_df = summary_df

    def get_summary_df(self) -> pd.DataFrame:
        """
        Get summary dataframe.
        """
        if self._summary_df is None:
            logger.warning("WARNING: summary df is not set")
        return self._summary_df

    def set_per_ops_data(self, per_ops_data: dict) -> None:
        """Set per-operation latency breakdown data from run_agg."""
        self._per_ops_data = per_ops_data

    def get_per_ops_data(self) -> dict | None:
        """Get per-operation latency breakdown data (populated by run_agg)."""
        return self._per_ops_data

    def set_per_ops_source(self, per_ops_source: dict) -> None:
        """Set per-operation data-source breakdown ("silicon"/"empirical"/"sol"/"mixed")."""
        self._per_ops_source = per_ops_source

    def get_per_ops_source(self) -> dict | None:
        """Get per-operation data-source breakdown, parallel to per_ops_data."""
        return self._per_ops_source

    def set_encoder_source_dict(self, encoder_source_dict: dict) -> None:
        """Set the per-op data source dict for the encoder phase."""
        self._encoder_source_dict = encoder_source_dict

    def get_encoder_source_dict(self) -> dict:
        """Get the per-op data source dict for the encoder phase."""
        return self._encoder_source_dict

    def set_context_source_dict(self, context_source_dict: dict) -> None:
        """Set the per-op data source dict for the context (prefill) phase."""
        self._context_source_dict = context_source_dict

    def get_context_source_dict(self) -> dict:
        """Get the per-op data source dict for the context (prefill) phase."""
        return self._context_source_dict

    def set_generation_source_dict(self, generation_source_dict: dict) -> None:
        """Set the per-op data source dict for the generation (decode) phase."""
        self._generation_source_dict = generation_source_dict

    def get_generation_source_dict(self) -> dict:
        """Get the per-op data source dict for the generation (decode) phase."""
        return self._generation_source_dict

    # --- Capacity / KV-per-seq probing context (used by CLI detail reports) ---

    def set_kv_per_seq(self, kv_bytes_per_seq: float, seq_len_used: int) -> None:
        """Stash per-sequence KV cache footprint context for capacity probing.

        Args:
            kv_bytes_per_seq: KV cache bytes consumed by a single sequence on
                one GPU at the seq length actually used for memory estimation.
            seq_len_used: The seq length used (typically ``isl + beam_width * osl``,
                or ``max_seq_len`` when provided by the backend).
        """
        self._kv_bytes_per_seq = float(kv_bytes_per_seq)
        self._kv_seq_len_used = int(seq_len_used)

    def get_kv_per_seq(self) -> tuple[float | None, int | None]:
        """Return the (kv_bytes_per_seq, seq_len_used) pair, or (None, None) if unset."""
        return self._kv_bytes_per_seq, self._kv_seq_len_used

    def get_mem_capacity_bytes(self) -> int | None:
        """Return the GPU memory capacity (bytes) captured by set_memory_and_check_oom, or None."""
        return self._mem_capacity_bytes

    def set_result_dict(self, result_dict: dict) -> None:
        """
        Set the cached result dict for efficient batch operations.
        """
        self._result_dict = result_dict

    def get_result_dict(self) -> dict | None:
        """
        Get the result as a dict. Returns cached dict if available,
        otherwise extracts from the first row of the summary DataFrame.
        """
        if self._result_dict is not None:
            return self._result_dict

        # Fallback: create from DataFrame if not cached
        if self._summary_df is not None and len(self._summary_df) > 0:
            return self._summary_df.iloc[0].to_dict()
        return None
