# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import dataclasses
import json
import logging
import os
import random
import traceback

import matplotlib.pyplot as plt
import pandas as pd
import yaml
from prettytable import PrettyTable

from aiconfigurator.generator.api import (
    generate_from_request,
    get_default_dynamo_version_mapping,
    load_generator_overrides_from_args,
    resolve_backend_version_for_dynamo,
)
from aiconfigurator.generator.module_bridge import task_config_to_generator_config
from aiconfigurator.generator.request import from_legacy_params
from aiconfigurator.logging_utils import _cli_bold, _cli_underline
from aiconfigurator.sdk import pareto_analysis
from aiconfigurator.sdk.pareto_analysis import draw_pareto_to_string
from aiconfigurator.sdk.task_v2 import Task
from aiconfigurator.sdk.utils import safe_mkdir

logger = logging.getLogger(__name__)


def _apply_inclusive_tpot(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of df with tpot replaced by inclusive semantics.

    inclusive tpot = (ttft + tpot * (osl - 1)) / osl
    Applied to output copies only — never to internal computation DataFrames.
    """
    if "ttft" in df.columns:
        df = df.copy()
        df["tpot"] = (df["ttft"] + df["tpot"] * (df["osl"] - 1)) / df["osl"]
    return df


def _check_power_data_available(best_configs: dict[str, pd.DataFrame], threshold: float = 0.9) -> bool:
    """
    Check if power data is available and meaningful across configurations.

    Args:
        best_configs: Dictionary of experiment name to best configurations DataFrame
        threshold: Minimum ratio of configs with meaningful power data (default 0.9)

    Returns:
        True if power data should be displayed (>= threshold of configs have power >= 1W)
    """
    total_count = 0
    power_count = 0

    for exp_name, config_df in best_configs.items():
        if config_df is not None and not config_df.empty and "power_w" in config_df.columns:
            power_values = config_df["power_w"].values
            total_count += len(power_values)
            # Count how many configs have meaningful power data (>= 1W)
            power_count += sum(1 for p in power_values if p >= 1.0)

    if total_count == 0:
        return False

    # Show power column if >= threshold of configs have meaningful power data
    power_ratio = power_count / total_count
    return power_ratio >= threshold


def _plot_worker_setup_table(
    exp_name: str,
    config_df: pd.DataFrame,
    total_gpus: int,
    tpot_target: float,
    top: int,
    is_moe: bool,
    request_latency_target: float | None,
    show_power: bool = True,
    preserve_ranking: bool = False,
    objective_target: str | None = None,
) -> str:
    """Plot worker setup table for a single experiment."""
    buf = []

    if config_df is None or config_df.empty:
        return ""

    config_df = config_df.copy()
    if preserve_ranking:
        # A Spica replay row is already a complete evaluated deployment (and may
        # have been planner-scaled). Do not extrapolate it to the search budget or
        # re-rank it by the legacy throughput/GPU heuristic.
        config_df["tokens/s/gpu_cluster"] = config_df["tokens/s/gpu"]
    else:
        config_df["tokens/s/gpu_cluster"] = (
            config_df["tokens/s/gpu"]
            * (total_gpus // config_df["num_total_gpus"])
            * config_df["num_total_gpus"]
            / total_gpus
            if total_gpus > 0
            else 0
        )
    constraint_col = "tpot"
    constraint_target = tpot_target
    constraint_label = "TPOT"
    if request_latency_target is not None and request_latency_target > 0:
        constraint_col = "request_latency"
        constraint_target = request_latency_target
        constraint_label = "request latency"
    if preserve_ranking:
        # Native Spica objectives already define feasibility/ranking. In
        # particular, goodput uses per-request SLA accounting, so an aggregate
        # mean-latency gate here would incorrectly hide a valid selected row.
        top_configs = config_df.copy()
    elif constraint_target is not None and constraint_target > 0:
        top_configs = config_df[config_df[constraint_col] <= constraint_target].copy()
    else:
        top_configs = config_df.copy()
    if not preserve_ranking:
        top_configs = top_configs.sort_values(by="tokens/s/gpu_cluster", ascending=False)
    top_configs = top_configs.head(top).copy()

    if top_configs.empty:
        return f"\nNo configurations for {exp_name} met the {constraint_label} constraint."

    if preserve_ranking:
        top_configs["replicas"] = 1
        top_configs["total_gpus_used"] = top_configs["num_total_gpus"]
    else:
        top_configs["replicas"] = total_gpus // top_configs["num_total_gpus"]
        top_configs["total_gpus_used"] = top_configs["num_total_gpus"] * top_configs["replicas"]

    ranking_label = objective_target if preserve_ranking and objective_target else "tokens/s/gpu"
    buf.append(f"\n{exp_name} Top Configurations: (Ranked by {ranking_label})")
    table = PrettyTable()

    # Check if it is disagg config by checking for prefill/decode specific columns
    is_disagg = "(p)tp" in top_configs.columns

    top_configs["cluster_request_rate"] = (
        top_configs["request_rate"] if preserve_ranking else top_configs["request_rate"] * top_configs["replicas"]
    )

    if is_disagg:
        field_names = [
            "Rank",
            "backend",
            _cli_bold("tokens/s/gpu"),
            "tokens/s/user",
            "req/s",
            "TTFT",
            "request_latency",
            "concurrency",
            "total_gpus (used)",
            "replicas",
            "gpus/replica",
            "(p)workers",
            "(p)gpus/worker",
            "(p)parallel",
            "(p)bs",
            "(d)workers",
            "(d)gpus/worker",
            "(d)parallel",
            "(d)bs",
        ]
        if show_power:
            field_names.append("power_w")
        table.field_names = field_names
        for i, row in enumerate(top_configs.to_dict("records")):
            display_total_gpus = row["total_gpus_used"] if preserve_ranking else total_gpus
            display_concurrency = row["concurrency"] if preserve_ranking else row["concurrency"] * row["replicas"]
            if is_moe:
                p_parallel = (
                    f"tp{_cli_underline(str(row['(p)tp']))}"
                    f"pp{_cli_underline(str(row['(p)pp']))}"
                    f"dp{_cli_underline(str(row['(p)dp']))}"
                    f"etp{row['(p)moe_tp']}ep{row['(p)moe_ep']}"
                )
                d_parallel = (
                    f"tp{_cli_underline(str(row['(d)tp']))}"
                    f"pp{_cli_underline(str(row['(d)pp']))}"
                    f"dp{_cli_underline(str(row['(d)dp']))}"
                    f"etp{row['(d)moe_tp']}ep{row['(d)moe_ep']}"
                )
                p_gpus_worker = (
                    f"{row['(p)pp'] * row['(p)tp'] * row['(p)dp']} "
                    f"(={_cli_underline(str(row['(p)tp']))}x"
                    f"{_cli_underline(str(row['(p)pp']))}x"
                    f"{_cli_underline(str(row['(p)dp']))})"
                )
                d_gpus_worker = (
                    f"{row['(d)pp'] * row['(d)tp'] * row['(d)dp']} "
                    f"(={_cli_underline(str(row['(d)tp']))}x"
                    f"{_cli_underline(str(row['(d)pp']))}x"
                    f"{_cli_underline(str(row['(d)dp']))})"
                )
            else:
                p_parallel = f"tp{_cli_underline(str(row['(p)tp']))}pp{_cli_underline(str(row['(p)pp']))}"
                d_parallel = f"tp{_cli_underline(str(row['(d)tp']))}pp{_cli_underline(str(row['(d)pp']))}"
                p_gpus_worker = (
                    f"{row['(p)pp'] * row['(p)tp']} "
                    f"(={_cli_underline(str(row['(p)tp']))}x"
                    f"{_cli_underline(str(row['(p)pp']))})"
                )
                d_gpus_worker = (
                    f"{row['(d)pp'] * row['(d)tp']} "
                    f"(={_cli_underline(str(row['(d)tp']))}x"
                    f"{_cli_underline(str(row['(d)pp']))})"
                )
            gpus_replica_str = (
                f"{row['num_total_gpus']} "
                f"(={row['(p)workers']}x{row['(p)pp'] * row['(p)tp'] * row['(p)dp']}"
                f"+{row['(d)workers']}x{row['(d)pp'] * row['(d)tp'] * row['(d)dp']})"
            )
            row_data = [
                i + 1,
                row["backend"],
            ]
            row_data.extend(
                [
                    _cli_bold(f"{row['tokens/s/gpu_cluster']:.2f}"),
                    f"{row['tokens/s/user']:.2f}",
                    f"{row['cluster_request_rate']:.2f}",
                    f"{row['ttft']:.2f}",
                    f"{row['request_latency']:.2f}",
                    f"{display_concurrency} (={row['concurrency']}x{row['replicas']})",
                    f"{display_total_gpus} ({row['total_gpus_used']}={row['replicas']}x{row['num_total_gpus']})",
                    row["replicas"],
                    gpus_replica_str,
                    row["(p)workers"],
                    p_gpus_worker,
                    p_parallel,
                    row["(p)bs"],
                    row["(d)workers"],
                    d_gpus_worker,
                    d_parallel,
                    row["(d)bs"],
                ]
            )
            if show_power:
                row_data.append(f"{row['power_w']:.1f}W")
            table.add_row(row_data)
    else:  # agg
        field_names = [
            "Rank",
            "backend",
            _cli_bold("tokens/s/gpu"),
            "tokens/s/user",
            "req/s",
            "TTFT",
            "request_latency",
            "concurrency",
            "total_gpus (used)",
            "replicas",
            "gpus/replica",
            "gpus/worker",
            "parallel",
            "bs",
        ]
        if show_power:
            field_names.append("power_w")
        table.field_names = field_names
        for i, row in enumerate(top_configs.to_dict("records")):
            display_total_gpus = row["total_gpus_used"] if preserve_ranking else total_gpus
            display_concurrency = row["concurrency"] if preserve_ranking else row["concurrency"] * row["replicas"]
            if is_moe:
                parallel = (
                    f"tp{_cli_underline(str(row['tp']))}"
                    f"pp{_cli_underline(str(row['pp']))}"
                    f"dp{_cli_underline(str(row['dp']))}"
                    f"etp{row['moe_tp']}ep{row['moe_ep']}"
                )
                gpus_worker = (
                    f"{row['pp'] * row['tp'] * row['dp']} "
                    f"(={_cli_underline(str(row['tp']))}x"
                    f"{_cli_underline(str(row['pp']))}x"
                    f"{_cli_underline(str(row['dp']))})"
                )
            else:
                parallel = f"tp{_cli_underline(str(row['tp']))}pp{_cli_underline(str(row['pp']))}"
                gpus_worker = (
                    f"{row['pp'] * row['tp']} (={_cli_underline(str(row['tp']))}x{_cli_underline(str(row['pp']))})"
                )
            row_data = [
                i + 1,
                row["backend"],
            ]
            row_data.extend(
                [
                    _cli_bold(f"{row['tokens/s/gpu_cluster']:.2f}"),
                    f"{row['tokens/s/user']:.2f}",
                    f"{row['cluster_request_rate']:.2f}",
                    f"{row['ttft']:.2f}",
                    f"{row['request_latency']:.2f}",
                    f"{display_concurrency} (={row['concurrency']}x{row['replicas']})",
                    f"{display_total_gpus} ({row['total_gpus_used']}={row['replicas']}x{row['num_total_gpus']})",
                    row["replicas"],
                    row["num_total_gpus"],
                    gpus_worker,
                    parallel,
                    row["bs"],
                ]
            )
            if show_power:
                row_data.append(f"{row['power_w']:.1f}W")
            table.add_row(row_data)

    buf.append(table.get_string())
    return "\n".join(buf)


_OBJECTIVE_LABELS = {
    "throughput": "throughput",
    "throughput_per_gpu": "throughput per GPU",
    "throughput_per_user": "throughput per user",
    "e2e_latency": "end-to-end latency",
    "goodput": "goodput",
    "goodput_per_gpu": "goodput per GPU",
    "pareto": "Pareto",
}

_OBJECTIVE_UNITS = {
    "throughput": "tokens/s",
    "throughput_per_gpu": "tokens/s/gpu",
    "throughput_per_user": "tokens/s/user",
    "e2e_latency": "ms",
    "goodput": "tokens/s",
    "goodput_per_gpu": "tokens/s/gpu",
}


def _format_objective_value(target: str, value: object) -> str:
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return "n/a"
    if pd.isna(numeric):
        return "n/a"
    unit = _OBJECTIVE_UNITS.get(target)
    return f"{numeric:,.2f}{f' {unit}' if unit else ''}"


def log_final_summary(
    chosen_exp: str,
    best_throughputs: dict[str, float],
    best_configs: dict[str, pd.DataFrame],
    pareto_fronts: dict[str, pd.DataFrame | None],
    tasks: dict[str, Task],
    mode: str,
    pareto_x_axis: dict[str, str] | None = None,
    top_n: int = 5,
    target_request_rate: float | None = None,
    target_concurrency: float | None = None,
    inclusive_tpot: bool = False,
    extra_input_lines: list[str] | None = None,
    objective_target: str | None = None,
    best_objective_scores: dict[str, float] | None = None,
    pareto_y_axis: dict[str, str] | None = None,
    objective_directions: dict[str, bool] | None = None,
):
    """Log final summary of configuration results"""
    # display_* copies carry inclusive TPOT for printed values only.
    # The originals are kept for _plot_worker_setup_table which does TPOT filtering.
    if inclusive_tpot:
        display_best_configs = {k: _apply_inclusive_tpot(v) for k, v in best_configs.items()}
        display_pareto_fronts = {
            k: _apply_inclusive_tpot(v) if v is not None else None for k, v in pareto_fronts.items()
        }
    else:
        display_best_configs = best_configs
        display_pareto_fronts = pareto_fronts

    load_match = target_request_rate is not None or target_concurrency is not None
    objective_aware = objective_target is not None and best_objective_scores is not None

    # Consolidate and format results into a summary box for clear presentation
    summary_box = []
    summary_box.append("*" * 80)
    summary_box.append("*{:^78}*".format(" AIConfigurator Final Results "))
    summary_box.append("*" * 80)

    summary_box.append("  " + "-" * 76)
    summary_box.append("  Input Configuration & SLA Target:")

    # For multi-backend mode, get task using the backend from best_configs
    chosen_best_config = best_configs.get(chosen_exp)
    if chosen_best_config is not None and "backend" in chosen_best_config.columns and not chosen_best_config.empty:
        chosen_backend = chosen_best_config["backend"].iloc[0]
        task_key = f"{chosen_exp}_{chosen_backend}"
        # Verify the key exists (for multi-backend mode)
        if task_key in tasks:
            chosen_task = tasks[task_key]
        else:
            chosen_task = tasks[chosen_exp]
    else:
        chosen_task = tasks[chosen_exp]

    summary_box.append(f"    Model: {chosen_task.primary_model_path} (is_moe: {chosen_task.is_moe})")
    summary_box.append(f"    Total GPUs: {chosen_task.total_gpus}")
    if extra_input_lines:
        for line in extra_input_lines:
            summary_box.append(f"    {line}")
    if objective_aware:
        if objective_target == "pareto":
            x_axis = (pareto_x_axis or {}).get(chosen_exp, "unknown")
            y_axis = (pareto_y_axis or {}).get(chosen_exp, "unknown")
            summary_box.append(f"    Optimization Objective: Pareto ({y_axis} vs {x_axis})")
        else:
            maximize = (objective_directions or {}).get(objective_target, objective_target != "e2e_latency")
            direction = "maximize" if maximize else "minimize"
            label = _OBJECTIVE_LABELS.get(objective_target, objective_target)
            summary_box.append(f"    Optimization Objective: {label} ({direction})")

    if load_match:
        # Load-match mode summary
        if target_request_rate is not None:
            summary_box.append(f"    Target Load: {target_request_rate} req/s")
        else:
            summary_box.append(f"    Target Concurrency: {target_concurrency}")
        # Show GPUs needed for each mode (and load_served_pct if capacity exceeded)
        for exp_name, df in best_configs.items():
            if df is not None and not df.empty and "total_gpus_needed" in df.columns:
                row = df.iloc[0]
                gpus = int(row["total_gpus_needed"])
                replicas = int(row["replicas_needed"])
                line = f"    {exp_name} GPUs needed: {gpus} (replicas: {replicas})"
                if "load_served_pct" in df.columns:
                    pct = float(row["load_served_pct"])
                    if pct < 100.0:
                        line += f" -- WARNING: only {pct:.1f}% of target load can be served"
                summary_box.append(line)
        summary_box.append(f"    Best Experiment Chosen: {_cli_bold(chosen_exp)}")
    elif objective_aware:
        chosen_row = best_configs[chosen_exp].iloc[0] if not best_configs[chosen_exp].empty else pd.Series(dtype=object)
        if objective_target == "pareto":
            primary_axis = (pareto_y_axis or {}).get(chosen_exp, "objective_value")
            raw_value = chosen_row.get(primary_axis)
            value_text = _format_objective_value(primary_axis, raw_value)
            bold_msg = _cli_bold(f"{chosen_exp} at {primary_axis}={value_text}")
            summary_box.append(f"    Representative Experiment: {bold_msg} (primary Pareto objective)")
        else:
            raw_value = chosen_row.get("objective_value")
            value_text = _format_objective_value(objective_target, raw_value)
            label = _OBJECTIVE_LABELS.get(objective_target, objective_target)
            comparisons = []
            for exp_name, config_df in best_configs.items():
                if config_df is None or config_df.empty:
                    continue
                comparisons.append(
                    f"{exp_name}={_format_objective_value(objective_target, config_df.iloc[0].get('objective_value'))}"
                )
            comparison_text = f"; {', '.join(comparisons)}" if len(comparisons) > 1 else ""
            bold_msg = _cli_bold(f"{chosen_exp} at {value_text} {label}{comparison_text}")
            summary_box.append(f"    Best Experiment Chosen: {bold_msg}")
    elif mode == "default":
        agg_value = best_throughputs.get("agg", 0.0)
        disagg_value = best_throughputs.get("disagg", 0.0)
        if "agg" in best_throughputs and "disagg" in best_throughputs:
            if agg_value == disagg_value:
                comparison = "agg and disagg tied"
            else:
                winner, loser = ("agg", "disagg") if agg_value >= disagg_value else ("disagg", "agg")
                loser_value = best_throughputs[loser]
                benefit_ratio = float("inf") if loser_value == 0 else best_throughputs[winner] / loser_value
                comparison = f"{winner} {benefit_ratio:.2f}x better than {loser}"
            bold_msg = _cli_bold(f"{chosen_exp} at {best_throughputs[chosen_exp]:.2f} tokens/s/gpu ({comparison})")
        else:
            bold_msg = _cli_bold(f"{chosen_exp} at {best_throughputs[chosen_exp]:.2f} tokens/s/gpu")
        summary_box.append(f"    Best Experiment Chosen: {bold_msg}")
    else:
        bold_msg = _cli_bold(f"{chosen_exp} at {best_throughputs[chosen_exp]:.2f} tokens/s/gpu")
        summary_box.append(f"    Best Experiment Chosen: {bold_msg}")

    summary_box.append("  " + "-" * 76)

    # ============================= overall summary
    summary_box.append("  Selected Configuration:" if objective_aware else "  Overall Best Configuration:")
    best_config_df = display_best_configs[chosen_exp]
    best_throughput = best_throughputs[chosen_exp]

    if not best_config_df.empty:
        best_conf_details = best_config_df.iloc[0]
        if objective_aware:
            if objective_target == "pareto":
                x_axis = (pareto_x_axis or {}).get(chosen_exp)
                y_axis = (pareto_y_axis or {}).get(chosen_exp)
                if y_axis:
                    summary_box.append(
                        f"    - Primary Pareto Objective ({y_axis}): "
                        f"{_format_objective_value(y_axis, best_conf_details.get(y_axis))}"
                    )
                if x_axis and x_axis != y_axis:
                    summary_box.append(
                        f"    - Secondary Pareto Objective ({x_axis}): "
                        f"{_format_objective_value(x_axis, best_conf_details.get(x_axis))}"
                    )
            else:
                label = _OBJECTIVE_LABELS.get(objective_target, objective_target)
                summary_box.append(
                    f"    - Objective ({label}): "
                    f"{_format_objective_value(objective_target, best_conf_details.get('objective_value'))}"
                )

            physical_throughput = best_conf_details.get("throughput")
            if physical_throughput is not None and not pd.isna(physical_throughput):
                summary_box.append(f"    - Throughput: {float(physical_throughput):,.2f} tokens/s")
            summary_box.append(f"    - Per-GPU Throughput: {best_throughput:.2f} tokens/s/gpu")
            average_gpus = best_conf_details.get("average_gpus")
            if average_gpus is not None and not pd.isna(average_gpus):
                summary_box.append(f"    - Average Provisioned GPUs: {float(average_gpus):.2f}")
        else:
            summary_box.append(f"    - Best Throughput: {best_throughput * chosen_task.total_gpus:,.2f} tokens/s")
            summary_box.append(f"    - Per-GPU Throughput: {best_throughput:.2f} tokens/s/gpu")
        summary_box.append(f"    - Per-User Throughput: {best_conf_details['tokens/s/user']:.2f} tokens/s/user")
        if objective_aware:
            cluster_rr = float(best_conf_details["request_rate"])
        else:
            replicas = chosen_task.total_gpus // int(best_conf_details["num_total_gpus"])
            cluster_rr = float(best_conf_details["request_rate"]) * replicas
        summary_box.append(f"    - Request Rate: {cluster_rr:.2f} req/s")
        summary_box.append(f"    - TTFT: {best_conf_details['ttft']:.2f}ms")
        summary_box.append(f"    - TPOT: {best_conf_details['tpot']:.2f}ms")
        summary_box.append(f"    - Request Latency: {best_conf_details['request_latency']:.2f}ms")
    elif not objective_aware:
        summary_box.append(f"    - Best Throughput: {best_throughput * chosen_task.total_gpus:,.2f} tokens/s")
        summary_box.append(f"    - Per-GPU Throughput: {best_throughput:.2f} tokens/s/gpu")
    summary_box.append("  " + "-" * 76)

    # ============================= pareto frontier
    pareto_plot_buf = ""
    if len(display_pareto_fronts) <= 10:  # avoid overly crowded plots
        target_x_axis = "tokens/s/user"
        target_y_axis = "tokens/s/gpu_cluster"
        if pareto_x_axis:
            target_x_axis = pareto_x_axis.get(chosen_exp, target_x_axis)
        if pareto_y_axis:
            target_y_axis = pareto_y_axis.get(chosen_exp, target_y_axis)
        series_payload = []
        if target_x_axis != target_y_axis:
            for name, df in display_pareto_fronts.items():
                if df is None or df.empty:
                    continue
                series_x_axis = pareto_x_axis.get(name, target_x_axis) if pareto_x_axis else target_x_axis
                series_y_axis = pareto_y_axis.get(name, target_y_axis) if pareto_y_axis else target_y_axis
                if series_x_axis != target_x_axis or series_y_axis != target_y_axis:
                    continue
                if target_x_axis not in df.columns or target_y_axis not in df.columns:
                    continue
                series_payload.append({"df": df, "label": name})
        if series_payload:
            summary_box.append("  Pareto Frontier:")
            highlight_series = None
            if (
                not best_config_df.empty
                and target_x_axis in best_config_df.columns
                and target_y_axis in best_config_df.columns
            ):
                highlight_series = {
                    "df": best_config_df.head(1),
                    "label": f"{chosen_exp} selected",
                }
            pareto_plot_buf = draw_pareto_to_string(
                f"{chosen_task.primary_model_path} Pareto Frontier",
                series_payload,
                highlight=highlight_series,
                x_label=target_x_axis,
                y_label=target_y_axis,
            )
            summary_box.append(pareto_plot_buf)
    summary_box.append("  " + "-" * 76)

    # ============================= deployment details
    summary_box.append("  Deployment Details:")
    summary_box.append(
        "    (p) stands for prefill, (d) stands for decode, bs stands for batch size, "
        "a replica stands for the smallest scalable unit xPyD of the disagg system"
    )
    summary_box.append("    Some math: total gpus used = replicas * gpus/replica")
    summary_box.append(
        "               gpus/replica = (p)gpus/worker * (p)workers + (d)gpus/worker * (d)workers; "
        "for Agg, gpus/replica = gpus/worker"
    )
    summary_box.append(
        "               gpus/worker = tp * pp * dp = etp * ep * pp for MoE models; "
        f"tp * pp for dense models (underlined {_cli_underline('numbers')} are the actual values in math)"
    )

    # Check if power data is available before plotting tables
    show_power = _check_power_data_available(best_configs)

    # Plot worker setup tables for all experiments
    for exp_name, config_df in best_configs.items():
        # For multi-backend mode, use the first backend's config for table display
        # (total_gpus, is_moe, etc. should be the same across backends)
        if "backend" in config_df.columns and not config_df.empty:
            first_backend = config_df["backend"].iloc[0]
            task_key = f"{exp_name}_{first_backend}"
            # Verify the key exists (for multi-backend mode)
            if task_key not in tasks:
                task_key = exp_name
        else:
            task_key = exp_name

        if task_key not in tasks:
            logger.info("No task config for %s, skipping deployment table.", exp_name)
            continue

        if not config_df.empty and "backend" not in config_df.columns:
            config_df = config_df.copy()
            config_df["backend"] = tasks[task_key].primary_backend_name

        exp_task = tasks[task_key]
        total_gpus = getattr(exp_task, "total_gpus", None) or 0
        table_buf = _plot_worker_setup_table(
            exp_name,
            config_df,
            total_gpus,
            exp_task.tpot,
            top_n,
            exp_task.is_moe,
            exp_task.request_latency,
            show_power,
            preserve_ranking=objective_aware,
            objective_target=objective_target,
        )
        summary_box.append(table_buf)

    summary_box.append("*" * 80)
    logger.info("\n" + "\n".join(summary_box))


def save_results(
    args,
    best_configs: dict[str, pd.DataFrame],
    pareto_fronts: dict[str, pd.DataFrame | None],
    tasks: dict[str, Task],
    save_dir: str,
    generated_backend_version: str | None = None,
    backend: str | None = None,
):
    """Save the results to a directory."""
    # display_* copies carry inclusive TPOT for CSV/plot output only.
    # Originals are kept for artifact generation (task_config_to_generator_config).
    if getattr(args, "inclusive_tpot", False):
        display_best_configs = {k: _apply_inclusive_tpot(v) for k, v in best_configs.items()}
        display_pareto_fronts = {
            k: _apply_inclusive_tpot(v) if v is not None else None for k, v in pareto_fronts.items()
        }
    else:
        display_best_configs = best_configs
        display_pareto_fronts = pareto_fronts

    first_exp_name = list(tasks.keys())[0]
    first_task = tasks[first_exp_name]

    backend_str = backend or first_task.primary_backend_name

    # Get a safe model name for directory naming:
    # - For local paths: use basename (e.g., "/data/models/my_model" -> "my_model")
    # - For root path: return "root" (e.g., "/" -> "root")
    # - For HuggingFace IDs: return as-is (e.g., "Qwen/Qwen3-32B" -> "Qwen/Qwen3-32B")
    def get_safe_model_name(path: str) -> str:
        # Check if it's a local path (existing directory)
        if os.path.isdir(path):
            # Use abspath to resolve .. and . to actual path
            normalized = os.path.abspath(path)
            basename = os.path.basename(normalized)
            return basename if basename else "root"
        # Otherwise treat as HuggingFace model ID
        return path

    safe_model_name = get_safe_model_name(first_task.primary_model_path)

    result_prefix = (
        f"{safe_model_name}_{first_task.primary_system_name}_{backend_str}_"
        f"isl{first_task.isl}_osl{first_task.osl}_"
        f"ttft{int(first_task.ttft)}_tpot{int(first_task.tpot)}"
    )
    result_dir_path = os.path.join(save_dir, f"{result_prefix}_{random.randint(0, 1000000)}")

    logger.info(f"Saving results to {result_dir_path}")
    try:
        safe_result_dir = safe_mkdir(result_dir_path, exist_ok=True)
        generator_overrides = load_generator_overrides_from_args(args)

        # Save overall pareto plots in the root directory
        fig, ax = plt.subplots(1, 1, figsize=(8, 5))
        pareto_axis = {}
        for exp_name, cfg in tasks.items():
            if cfg.request_latency is not None and cfg.request_latency > 0:
                pareto_axis[exp_name] = "request_latency"
            else:
                pareto_axis[exp_name] = "tokens/s/user"
        all_request_latency = bool(pareto_axis) and all(axis == "request_latency" for axis in pareto_axis.values())
        global_x_axis = "request_latency" if all_request_latency else "tokens/s/user"
        maximize_x = not all_request_latency
        plt.title(f"{first_task.primary_model_path} tokens/s/gpu vs {global_x_axis}")

        # Define markers for backends and colors for serving modes
        backend_markers = {
            "trtllm": "o",  # circle
            "vllm": "s",  # square
            "sglang": "^",  # triangle
        }
        serving_mode_colors = {
            "agg": "#1f77b4",  # blue
            "disagg": "#ff7f0e",  # orange
        }
        # Fallback colors for non-standard experiment names
        exp_colors = [
            "blue",
            "red",
            "green",
            "purple",
            "orange",
            "brown",
            "pink",
            "gray",
            "cyan",
            "magenta",
        ]
        color_idx = 0

        for exp_name, pareto_df in display_pareto_fronts.items():
            if pareto_df is None or pareto_df.empty:
                continue
            if pareto_axis.get(exp_name, global_x_axis) != global_x_axis:
                continue

            # Check if this is multi-backend mode (pareto_df has "backend" column)
            if "backend" in pareto_df.columns:
                # Plot each backend with different marker, color by serving mode (agg/disagg)
                # Note: pareto_df is already the combined Pareto frontier, so we just plot points
                # grouped by backend, without recomputing Pareto per backend
                color = serving_mode_colors.get(exp_name, exp_colors[color_idx % len(exp_colors)])
                for backend_name in pareto_df["backend"].unique():
                    backend_df = pareto_df[pareto_df["backend"] == backend_name].sort_values(by=global_x_axis)
                    marker = backend_markers.get(backend_name, "o")
                    label = f"{exp_name} ({backend_name})"
                    # Plot directly without recomputing Pareto
                    ax.plot(
                        backend_df[global_x_axis],
                        backend_df["tokens/s/gpu"],
                        color=color,
                        marker=marker,
                        label=label,
                        linestyle="-",
                        markersize=8,
                    )
                color_idx += 1
            else:
                # Single backend mode
                pareto_analysis.draw_pareto(
                    pareto_df,
                    global_x_axis,
                    "tokens/s/gpu",
                    ax,
                    exp_colors[color_idx % len(exp_colors)],
                    exp_name,
                    maximize_x=maximize_x,
                )
                color_idx += 1

        # Add axis labels and legend
        ax.set_xlabel(global_x_axis)
        ax.set_ylabel("tokens/s/gpu")
        ax.legend()

        plt.savefig(os.path.join(safe_result_dir, "pareto_frontier.png"))
        plt.close()

        # Save each experiment's results in its own subdirectory
        for exp_name, pareto_df in display_pareto_fronts.items():
            exp_dir = os.path.join(safe_result_dir, exp_name)
            safe_mkdir(exp_dir, exist_ok=True)

            # 1. Save best config dataframe (display copy carries inclusive TPOT if flag set)
            #    Strip the object-typed _per_ops_source column before CSV write; it is
            #    saved as one per_ops_source.json per topN/ subdir below.
            best_config_df = display_best_configs.get(exp_name)  # top n configs
            best_config_per_ops_source: list[dict | None] = []
            if best_config_df is not None:
                if "_per_ops_source" in best_config_df.columns:
                    best_config_per_ops_source = best_config_df["_per_ops_source"].tolist()
                    best_config_df = best_config_df.drop(columns=["_per_ops_source"])
                best_config_df.to_csv(os.path.join(exp_dir, "best_config_topn.csv"), index=False)

            # 2. Save all pareto dataframe (also stripped of _per_ops_source)
            if pareto_df is not None:
                pareto_csv_df = pareto_df.drop(columns=["_per_ops_source"], errors="ignore")
                pareto_csv_df.to_csv(os.path.join(exp_dir, "pareto.csv"), index=False)

            # 3. Save the config for this experiment
            if backend != "auto":
                exp_task = tasks[exp_name]
                backend_version_str = exp_task.primary_backend_version
            else:
                # There could be multiple backends in the same experiment if backend == "auto" as the result is merged
                actual_backend_versions = {
                    task.primary_backend_name: task.primary_backend_version for task in tasks.values()
                }
                backend_version_str = ", ".join(
                    f"({backend_name}){backend_version}"
                    for backend_name, backend_version in actual_backend_versions.items()
                )
                exp_tasks = {
                    f"{exp_name}_{backend_name}": tasks[f"{exp_name}_{backend_name}"]
                    for backend_name in actual_backend_versions
                }
                # generated backend versions for each backend, empty unless --generator-dynamo-version is provided
                generated_backend_versions = {}

            # Search / perf-DB version echo: the performance data the sweep ran
            # against (search fidelity). This is distinct from the generated /
            # deployed config version shown in the box below -- the two axes are
            # decoupled (set via --perf-db-version; default: latest).
            logger.warning(
                "\n" + "=" * 80 + "\n"
                "  🔍  Search / perf-DB version (simulation fidelity)\n" + "=" * 80 + "\n"
                "  Experiment: %s\n"
                "  Perf-DB version: %s   (--perf-db-version; default: latest)\n"
                "  This is what the search simulated against; it may differ from the\n"
                "  generated/deployed config version shown next.\n" + "=" * 80,
                exp_name,
                backend_version_str or "latest",
            )

            # case #1: --generated-config-version is provided
            if generated_backend_version:
                effective_generated_version = generated_backend_version
                logger.warning(
                    "\n" + "=" * 80 + "\n"
                    "  🟢  IMPORTANT: Config Generation Version\n" + "=" * 80 + "\n"
                    "  Experiment: %s\n"
                    "  Using generated-config-version: %s\n"
                    "\n"
                    "  Config formats differ across backend releases. Please ensure you pass\n"
                    "  the correct --generated-config-version to match your deployment target!\n" + "=" * 80,
                    exp_name,
                    generated_backend_version,
                )
            # case #2: --generator_dynamo_version is provided, generating config matching the dynamo version,
            # but the data used for prediction may not match dynamo version due to imperfect coverage.
            elif dynamo_version := (generator_overrides or {}).get("generator_dynamo_version"):
                if backend != "auto":
                    try:
                        effective_generated_version = resolve_backend_version_for_dynamo(
                            dynamo_version,
                            exp_task.primary_backend_name,
                        )
                        backend_version_str = f"({exp_task.primary_backend_name}){effective_generated_version}"
                    except ValueError as exc:
                        logger.exception(
                            "Failed to resolve backend version for generator_dynamo_version=%s.",
                            dynamo_version,
                        )
                        raise SystemExit(2) from exc
                else:
                    generated_backend_versions = resolve_backend_version_for_dynamo(dynamo_version)
                    backend_version_str = ", ".join(
                        f"({backend_name}){backend_version}"
                        for backend_name, backend_version in generated_backend_versions.items()
                    )
                logger.warning(
                    "\n" + "=" * 80 + "\n"
                    "  🟢  IMPORTANT: Config Generation Version\n" + "=" * 80 + "\n"
                    "  Experiment: %s\n"
                    "  Using generator_dynamo_version: %s\n"
                    "  Generated backend version: %s\n"
                    "\n"
                    "  Config formats differ across backend releases. Ensure the Dynamo version\n"
                    "  matches your deployment target!\n" + "=" * 80,
                    exp_name,
                    dynamo_version,
                    backend_version_str,
                )
            # case #3: no override is provided, use the default backend version mapping
            else:
                deployment_target = getattr(args, "deployment_target", "dynamo-j2")
                default_dynamo_version, default_backend_versions = get_default_dynamo_version_mapping()
                if backend != "auto":
                    effective_generated_version = default_backend_versions.get(exp_task.primary_backend_name)
                    if effective_generated_version is None:
                        raise ValueError(
                            "No default backend version mapping for backend "
                            f"'{exp_task.primary_backend_name}' in dynamo '{default_dynamo_version}'."
                        )
                    backend_version_str = f"({exp_task.primary_backend_name}){effective_generated_version}"
                else:
                    generated_backend_versions = dict(default_backend_versions)
                    backend_version_str = ", ".join(
                        f"({backend_name}){backend_version}"
                        for backend_name, backend_version in generated_backend_versions.items()
                    )

                # Set version source based on deployment target
                if deployment_target == "llm-d-helm":
                    version_source = "template defaults"
                else:
                    version_source = f"dynamo {default_dynamo_version}"

                logger.warning(
                    "\n" + "=" * 80 + "\n"
                    "  🟢  IMPORTANT: Config Generation Version Not Specified\n" + "=" * 80 + "\n"
                    "  Experiment: %s\n"
                    "  --generated-config-version NOT provided\n"
                    "  Defaulting to backend version from %s: %s\n"
                    "\n"
                    "  Config formats differ across backend releases. If you are targeting\n"
                    "  a different version, please pass --generated-config-version explicitly!\n" + "=" * 80,
                    exp_name,
                    version_source,
                    backend_version_str,
                )

            # Save the experiment config for future aic repro
            if backend != "auto":
                with open(os.path.join(exp_dir, "exp_config.yaml"), "w") as f:
                    f.write(exp_task.to_yaml())
            else:
                for exp_task in exp_tasks.values():
                    exp_cfg_name = f"{exp_task.primary_backend_name}_exp_config.yaml"
                    with open(os.path.join(exp_dir, exp_cfg_name), "w") as f:
                        f.write(exp_task.to_yaml())

            # 4. Save the generated config for this experiment, sub-directory for each best config
            # Use original (non-display) data so --inclusive-tpot does not affect deployment artifacts.
            artifact_config_df = best_configs.get(exp_name)
            if artifact_config_df is not None:
                for i, (idx, result_df) in enumerate(artifact_config_df.iterrows()):
                    # For multi-backend mode, get the task for this row's backend
                    if backend == "auto" and "backend" in result_df:
                        row_backend = result_df["backend"]
                        row_task_key = f"{exp_name}_{row_backend}"
                        row_task = tasks[row_task_key]
                        row_backend_version = generated_backend_versions.get(
                            row_backend, row_task.primary_backend_version
                        )
                    else:
                        row_task = exp_task
                        row_backend_version = effective_generated_version

                    cfg = task_config_to_generator_config(
                        task_config=row_task,
                        result_df=result_df,
                        generator_overrides=generator_overrides,
                    )

                    top_config_dir = os.path.join(exp_dir, f"top{i + 1}")
                    safe_mkdir(top_config_dir, exist_ok=True)
                    with open(os.path.join(top_config_dir, "generator_config.yaml"), "w") as f:
                        yaml.safe_dump(cfg, f, sort_keys=False)

                    # Per-op data source breakdown (silicon / empirical / sol / mixed),
                    # pulled from PerformanceResult.source via the InferenceSummary.
                    # Same nested shape as per_ops_data, populated only when the row
                    # carried it through the pareto search.
                    if i < len(best_config_per_ops_source) and best_config_per_ops_source[i] is not None:
                        with open(os.path.join(top_config_dir, "per_ops_source.json"), "w") as f:
                            json.dump(best_config_per_ops_source[i], f, indent=2, sort_keys=True)

                    try:
                        deployment_target = getattr(args, "deployment_target", "dynamo-j2")
                        # Render through the typed request path. `cfg` (dumped to
                        # generator_config.yaml above) is the dict bridge output;
                        # lowering its request reproduces byte-identical artifacts
                        # (the request round-trip gate), so this is output-neutral.
                        req = from_legacy_params(cfg, backend=row_task.primary_backend_name)
                        req = dataclasses.replace(
                            req,
                            backend=dataclasses.replace(req.backend, generated_config_version=row_backend_version),
                            emit=dataclasses.replace(
                                req.emit,
                                deployment_target=deployment_target,
                                output_dir=top_config_dir,
                            ),
                        )
                        generate_from_request(req)
                    except Exception as exc:
                        logger.warning(
                            "Failed to generate backend config from aic generator: %s, %s",
                            exc,
                            traceback.format_exc(),
                        )

    except Exception:
        logger.exception("Failed to save results")
