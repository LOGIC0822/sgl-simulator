# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import gradio as gr

from aiconfigurator.sdk import common
from aiconfigurator.sdk.common import get_default_models
from aiconfigurator.sdk.perf_database import get_database, get_supported_databases


def create_model_path_config(app_config):
    """create model name config components"""
    default_models = sorted(get_default_models())
    default_model = "deepseek-ai/DeepSeek-V3" if "deepseek-ai/DeepSeek-V3" in default_models else default_models[0]
    with gr.Accordion("Model"):
        model_path = gr.Dropdown(
            choices=default_models,
            label="model name",
            value=default_model,
            interactive=True,
        )

    return {"model_path": model_path}


def create_system_config(app_config, gpu_config=False):
    """create system config components"""
    # Use get_supported_databases() to avoid loading all databases at startup
    supported_databases = get_supported_databases()
    system_choices = sorted(supported_databases.keys())
    default_system = "h200_sxm" if "h200_sxm" in system_choices else system_choices[0]
    backend_choices = sorted(supported_databases[default_system].keys())
    default_backend = "trtllm" if "trtllm" in backend_choices else backend_choices[0]
    version_choices = sorted(supported_databases[default_system][default_backend])
    default_version = version_choices[-1]

    with gr.Accordion("System config"):
        with gr.Row():
            system = gr.Dropdown(
                choices=system_choices,
                label="System",
                value=default_system,
                interactive=True,
            )
            backend = gr.Dropdown(
                choices=backend_choices,
                label="Backend",
                value=default_backend,
                interactive=True,
            )
            version = gr.Dropdown(
                choices=version_choices,
                label="Version",
                value=default_version,
                interactive=True,
            )
            database_mode = gr.Dropdown(
                choices=[
                    common.DatabaseMode.SILICON.name,
                    common.DatabaseMode.HYBRID.name,
                    common.DatabaseMode.EMPIRICAL.name,
                    common.DatabaseMode.SOL.name,
                ],
                label="Database Mode",
                value=common.DatabaseMode.SILICON.name,
                interactive=True,
            )
        if gpu_config:
            with gr.Row():
                gpu_config_components = {
                    "min_gpu_per_engine": gr.Number(
                        label="Minimum GPUs per engine",
                        value=4,
                        interactive=True,
                    ),
                    "max_gpu_per_engine": gr.Number(
                        label="Maximum GPUs per engine",
                        value=16,
                        interactive=True,
                    ),
                    "gpus_per_node": gr.Number(
                        label="GPUs per node",
                        value=8,
                        interactive=True,
                    ),
                }
        else:
            gpu_config_components = {}

    return {
        "system": system,
        "backend": backend,
        "version": version,
        "database_mode": database_mode,
        **gpu_config_components,
    }


def create_model_quant_config(app_config):
    """create model quantization config components"""
    # Use get_supported_databases() for structure, then load only the specific database needed
    supported_databases = get_supported_databases()
    system_choices = sorted(supported_databases.keys())
    default_system = "h200_sxm" if "h200_sxm" in system_choices else system_choices[0]
    backend_choices = sorted(supported_databases[default_system].keys())
    default_backend = "trtllm" if "trtllm" in backend_choices else backend_choices[0]
    version_choices = sorted(supported_databases[default_system][default_backend])
    default_version = version_choices[-1]
    # Load only the specific database we need
    database = get_database(default_system, default_backend, default_version)
    if database is None:
        raise ValueError(f"Could not load database for {default_system}/{default_backend}/{default_version}")
    gemm_quant_mode_choices = database.supported_quant_mode["gemm"]
    kvcache_quant_mode_choices = database.supported_quant_mode["generation_mla"]  # DS V3 by default
    fmha_quant_mode_choices = database.supported_quant_mode["context_mla"]  # DS V3 by default
    moe_quant_mode_choices = database.supported_quant_mode["moe"]
    # comm_quant_mode_choices = database.supported_quant_mode['comm']

    with gr.Accordion("Quantization config"):
        with gr.Row():
            default_gemm_quant_mode = (
                "fp8_block" if "fp8_block" in gemm_quant_mode_choices else gemm_quant_mode_choices[0]
            )
            gemm_quant_mode = gr.Dropdown(
                choices=gemm_quant_mode_choices,
                label="gemm quant mode",
                allow_custom_value=False,
                value=default_gemm_quant_mode,
                interactive=True,
            )
            kvcache_quant_mode = gr.Dropdown(
                choices=kvcache_quant_mode_choices,
                label="kvcache quant mode",
                allow_custom_value=False,
                value="fp8" if "fp8" in kvcache_quant_mode_choices else kvcache_quant_mode_choices[0],
                interactive=True,
            )
            fmha_quant_mode = gr.Dropdown(
                choices=fmha_quant_mode_choices,
                label="fmha quant mode",
                allow_custom_value=False,
                value="fp8" if "fp8" in fmha_quant_mode_choices else fmha_quant_mode_choices[0],
                interactive=True,
            )
            moe_quant_mode = gr.Dropdown(
                choices=moe_quant_mode_choices,
                label="moe quant mode",
                allow_custom_value=False,
                value="fp8_block" if "fp8_block" in moe_quant_mode_choices else moe_quant_mode_choices[0],
                interactive=True,
            )
            comm_quant_mode = gr.Dropdown(
                choices=common.CommQuantMode.__members__.keys(),
                label="comm quant mode",
                allow_custom_value=False,
                value="half",
                visible=False,
                interactive=True,
            )

    return {
        "gemm_quant_mode": gemm_quant_mode,
        "kvcache_quant_mode": kvcache_quant_mode,
        "fmha_quant_mode": fmha_quant_mode,
        "moe_quant_mode": moe_quant_mode,
        "comm_quant_mode": comm_quant_mode,
    }


def create_model_parallel_config(app_config, single_select=True, disagg=False):
    """create model parallel config components"""
    if single_select:
        with gr.Accordion("Parallel config"):
            with gr.Row():
                tp_size = gr.Dropdown(choices=[1, 2, 4, 8, 16, 32, 64], label="tp size", value=8, interactive=True)
                pp_size = gr.Dropdown(choices=[1, 2, 4, 8], label="pp size", value=1, interactive=True)
                dp_size = gr.Dropdown(
                    choices=[1, 2, 4, 8, 16, 32, 64, 128, 256],
                    label="dp size",
                    value=1,
                    interactive=True,
                )
                moe_tp_size = gr.Dropdown(choices=[1, 2, 4, 8, 16], label="moe tp size", value=1, interactive=True)
                moe_ep_size = gr.Dropdown(
                    choices=[1, 2, 4, 8, 16, 32, 64, 128, 256],
                    label="moe ep size",
                    value=8,
                    interactive=True,
                )
    else:
        with gr.Accordion("Parallel config"):
            with gr.Row():
                if disagg:
                    num_worker = gr.Number(label="num worker, -1 for auto", value=-1, interactive=True)
                num_gpus = gr.CheckboxGroup(
                    choices=[1, 2, 4, 8, 16, 32, 64, 128, 256],
                    label="num gpus in a worker",
                    value=8,
                    interactive=True,
                )
                tp_size = gr.CheckboxGroup(choices=[1, 2, 4, 8, 16, 32, 64], label="tp size", value=8, interactive=True)
                pp_size = gr.CheckboxGroup(choices=[1, 2, 4, 8], label="pp size", value=1, interactive=True)
                dp_size = gr.CheckboxGroup(
                    choices=[1, 2, 4, 8, 16, 32, 64, 128, 256],
                    label="dp size",
                    value=1,
                    interactive=True,
                )
                moe_tp_size = gr.CheckboxGroup(choices=[1, 2, 4, 8, 16], label="moe tp size", value=1, interactive=True)
                moe_ep_size = gr.CheckboxGroup(
                    choices=[1, 2, 4, 8, 16, 32, 64, 128, 256],
                    label="moe ep size",
                    value=8,
                    interactive=True,
                )
    components_dict = {
        "tp_size": tp_size,
        "pp_size": pp_size,
        "dp_size": dp_size,
        "moe_tp_size": moe_tp_size,
        "moe_ep_size": moe_ep_size,
    }
    if not single_select:
        components_dict["num_gpus"] = num_gpus
        if disagg:
            components_dict["num_worker"] = num_worker
    return components_dict


def create_model_misc_config(app_config):
    """create model misc config components"""
    with gr.Accordion("Misc config"):
        with gr.Row():
            nextn = gr.Dropdown(choices=[0, 1, 2, 3, 4, 5], value=0, label="nextn", interactive=True)
            nextn_accept_rates = gr.Textbox(value="0.85,0.3,0.0,0.0,0.0", label="nextn accept rates", interactive=True)
            enable_wideep = gr.Checkbox(label="enable wideep", value=False, interactive=True)
            enable_eplb = gr.Checkbox(label="enable eplb", value=False, interactive=False)

    return {
        "nextn": nextn,
        "nextn_accept_rates": nextn_accept_rates,
        "enable_wideep": enable_wideep,
        "enable_eplb": enable_eplb,
    }


def create_runtime_config(
    app_config,
    with_sla=False,
    prefix_length=True,
    tip_text=None,
    ttft_optional=False,
    itl_optional=False,
    with_request_latency=False,
    with_images=False,
):
    """create runtime config components"""

    with gr.Accordion("Runtime config"):
        if tip_text:
            with gr.Row():
                gr.HTML(f"<span style='color: var(--body-text-color-subdued);'>{tip_text}</span>")
        with gr.Row():
            isl = gr.Number(
                value=2048,
                label="input sequence length",
                interactive=True,
            )
            osl = gr.Number(
                value=128,
                label="output sequence length",
                interactive=True,
            )
            if prefix_length:
                prefix = gr.Number(value=0, label="prefix cache length", interactive=True)
            else:
                prefix = None

            if with_sla:
                ttft = gr.Number(value=2000, label="first token latency/ms", interactive=True, optional=ttft_optional)
                tpot = gr.Number(value=50, label="inter token latency/ms", interactive=True, optional=itl_optional)
                batch_size = None
            else:
                batch_size = gr.Number(value=1, label="batch size", interactive=True)
                ttft = None
                tpot = None

            if with_request_latency:
                request_latency = gr.Number(
                    value=None,
                    label="request latency/ms (optional, set e2e latency constraint)",
                    interactive=True,
                    optional=True,
                )
            else:
                request_latency = None

        if with_images:
            with gr.Row():
                gr.HTML(
                    "<span style='color: var(--body-text-color-subdued);'>Vision-language image config (set to 0 to skip encoder)</span>"
                )
            with gr.Row():
                image_height = gr.Number(value=448, label="image height (px)", interactive=True)
                image_width = gr.Number(value=448, label="image width (px)", interactive=True)
                num_images = gr.Number(value=0, label="images per request (0 = skip encoder)", interactive=True)
        else:
            image_height = None
            image_width = None
            num_images = None

        return {
            "isl": isl,
            "osl": osl,
            "prefix": prefix,
            "ttft": ttft,
            "tpot": tpot,
            "batch_size": batch_size,
            "request_latency": request_latency,
            "image_height": image_height,
            "image_width": image_width,
            "num_images": num_images,
        }
