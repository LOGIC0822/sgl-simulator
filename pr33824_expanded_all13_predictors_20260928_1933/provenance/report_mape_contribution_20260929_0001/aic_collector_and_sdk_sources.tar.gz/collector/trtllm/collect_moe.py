# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""TensorRT-LLM MoE collector for the current torch-flow API.

This collector handles the current create_moe/autotuner stack, newer activation and
FP4 paths, optional rank-local workload synthesis, and per-shape tuning caches.
Shared MoE shapes come from YAML; this file owns TRT-LLM version quirks and
kernel-specific filters.
"""

__compat__ = "trtllm>=1.0.0,<=1.3.0rc15"

import gc
import glob
import inspect
import json
import os
import random
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from types import SimpleNamespace

import tensorrt_llm
import torch
from tensorrt_llm._torch.autotuner import AutoTuner, autotune
from tensorrt_llm._torch.model_config import ModelConfig
from tensorrt_llm._torch.models.modeling_deepseekv3 import DeepseekV3Gate
from tensorrt_llm._torch.modules.fused_moe import RenormalizeMoeRoutingMethod, create_moe
from tensorrt_llm.mapping import Mapping
from tensorrt_llm.models.modeling_utils import QuantAlgo, QuantConfig

try:
    from tensorrt_llm._torch.utils import ActivationType
except ImportError:
    ActivationType = None

# Models that use non-gated MoE (Relu2 activation instead of SwiGLU)
# These are substring patterns that will be matched against the full model name
# supported in trtllm 1.3.0rc1, please expect failures for these models if using trtllm < 1.3.0rc1
NON_GATED_MOE_MODELS = ["Nemotron-3"]
_MXFP4_MOE_TYPES = {"w4a16_mxfp4", "w4a8_mxfp4_mxfp8"}

from collector.case_generator import (
    get_common_moe_test_cases,
    get_moe_quantization_module_config,
    moe_model_allows_quantization,
)
from collector.helper import (
    EXIT_CODE_RESTART,
    balanced_logits,
    benchmark_with_power,
    get_sm_version,
    log_perf,
    power_law_logits_v3,
)

aic_debug = int(os.getenv("aic_moe_debug", "0"))  # noqa: SIM112

moe_tune_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "moe_tuned_cache_path")
_TRTLLM_VERSION = tensorrt_llm.__version__


def _is_trtllm_130rc5_runtime():
    return _TRTLLM_VERSION.startswith("1.3.0rc5")


def _is_trtllm_130rc5_or_rc10_runtime():
    return _TRTLLM_VERSION.startswith(("1.3.0rc5", "1.3.0rc10"))


def _moe_model_behavior(model_name: str) -> str:
    """Resolve model-name branches that change the synthetic invocation."""
    if any(pattern in model_name for pattern in NON_GATED_MOE_MODELS):
        return "relu2"
    if model_name in {"openai/gpt-oss-120b", "openai/gpt-oss-20b"}:
        return "swigluoai"
    return "swiglu"


def _moe_execution_key(common_moe_testcase, moe_type: str, min_latency_mode: bool):
    module_config = get_moe_quantization_module_config(
        "trtllm",
        moe_type,
        model_name=common_moe_testcase.model_name,
    )
    return (
        moe_type,
        tuple(common_moe_testcase.num_tokens_list),
        common_moe_testcase.hidden_size,
        common_moe_testcase.inter_size,
        common_moe_testcase.topk,
        common_moe_testcase.num_experts,
        common_moe_testcase.tp,
        common_moe_testcase.ep,
        min_latency_mode,
        common_moe_testcase.token_expert_distribution,
        common_moe_testcase.power_law_alpha,
        _moe_model_behavior(common_moe_testcase.model_name),
        json.dumps(module_config, sort_keys=True, separators=(",", ":")),
    )


def _moe_consumer_keys(common_moe_testcase, moe_type: str, min_latency_mode: bool):
    """Return every consumer-visible key emitted by one getter task."""
    distribution = (
        f"power_law_{common_moe_testcase.power_law_alpha}"
        if common_moe_testcase.token_expert_distribution == "power_law"
        else common_moe_testcase.token_expert_distribution
    )
    table = "low_latency" if min_latency_mode else "default"
    return tuple(
        (
            table,
            moe_type,
            distribution,
            common_moe_testcase.topk,
            common_moe_testcase.num_experts,
            common_moe_testcase.hidden_size,
            common_moe_testcase.inter_size,
            common_moe_testcase.tp,
            common_moe_testcase.ep,
            num_tokens,
        )
        for num_tokens in common_moe_testcase.num_tokens_list
    )


def _patch_moe_runners_for_tuple_tactics():
    """Monkey-patch MoE runners whose forward() asserts isinstance(tactic, list).

    In trtllm 1.2.0rc5, the C++ get_valid_configs() can return strings instead
    of lists for some runners, causing the assertion to fail. This patch wraps
    forward() to coerce tuples to lists before the call.
    """
    if tensorrt_llm.__version__ != "1.2.0rc5" or get_sm_version() < 100:
        return

    try:
        from tensorrt_llm._torch.custom_ops import trtllm_gen_custom_ops as ops
    except ImportError:
        return

    runner_classes = []
    for name in [
        "MxE4m3MxE2m1BlockScaleMoERunner",
        "E4m3MxE2m1BlockScaleMoERunner",
        "Bf16MxE2m1BlockScaleMoERunner",
    ]:
        cls = getattr(ops, name, None)
        if cls is not None:
            runner_classes.append(cls)

    for cls in runner_classes:
        orig_forward = cls.forward

        def _patched_forward(self, inputs, tactic=[-1, -1], _orig=orig_forward, **kwargs):
            if not isinstance(tactic, list):
                if isinstance(tactic, str):
                    import ast

                    tactic = ast.literal_eval(tactic)
                elif isinstance(tactic, (tuple, range)):
                    tactic = list(tactic)
                else:
                    tactic = [tactic]
            return _orig(self, inputs, tactic=tactic, **kwargs)

        cls.forward = _patched_forward


_patch_moe_runners_for_tuple_tactics()


def gc_collect():
    """Run GC and clear CUDA cache to reduce fragmentation between runs."""
    for _ in range(2):
        gc.collect()
        torch.cuda.empty_cache()


def _process_json_file(file_path):
    """Process a single JSON file, returning (deleted, message) tuple."""
    try:
        if os.path.getsize(file_path) == 0:
            os.remove(file_path)
            return (True, f"Deleted empty file: {file_path}")
        else:
            with open(file_path) as f:
                data = json.load(f)
                if not data:
                    os.remove(file_path)
                    return (True, f"Deleted empty JSON content: {file_path}")
        return (False, None)
    except (OSError, json.JSONDecodeError) as e:
        try:
            os.remove(file_path)
            return (True, f"Deleted invalid file: {file_path} (Error: {e})")
        except OSError:
            return (False, None)


def cleanup_empty_json_files(directory):
    """Remove empty or invalid JSON files under directory (e.g. autotuner cache)."""
    if not os.path.exists(directory):
        return

    json_files = glob.glob(os.path.join(directory, "*.json"))
    deleted_count = 0

    # Parallelize io operations
    with ThreadPoolExecutor() as executor:
        futures = {executor.submit(_process_json_file, fp): fp for fp in json_files}
        for future in as_completed(futures):
            deleted, message = future.result()
            if deleted:
                deleted_count += 1
            if message:
                print(message)

    if deleted_count > 0:
        print(f"Total deleted {deleted_count} invalid JSON files from {directory}")


def get_moe_test_cases():
    """Build list of MoE test case tuples for trtllm >= 1.1 (power_law, SM-dependent quant modes)."""
    moe_list = ["bfloat16"]
    sm_version = get_sm_version()
    if sm_version > 86:
        moe_list += ["fp8"]
        # SM90 (Hopper) and SM100 (Blackwell) both support fp8_block.
        # SM90 uses CUTLASS backend with FP32 scale.
        # SM100 uses DEEPGEMM/TRTLLM backend with UE8M0 scale (MXFP8 style).
    if sm_version >= 90:
        moe_list += ["fp8_block"]

    # SM90 specific quant mode.
    if 86 < sm_version < 100:
        moe_list += ["w4a16_mxfp4"]

    if sm_version >= 100:
        # Keep plain INT4/W4A16 in the collector sweep so unsupported model rows
        # can fail in TensorRT-LLM itself instead of stopping at AIC validation.
        moe_list += ["int4_wo", "nvfp4", "w4a16_mxfp4", "w4a8_mxfp4_mxfp8"]

    test_cases = []
    seen = set()
    consumer_key_owners = {}

    for common_moe_testcase in get_common_moe_test_cases():
        model_name = common_moe_testcase.model_name
        inter_s = common_moe_testcase.inter_size
        moe_tp = common_moe_testcase.tp

        for moe_type in moe_list:
            if not moe_model_allows_quantization("trtllm", model_name, moe_type):
                continue

            # w4afp8 requires k shape to be multiple of 128
            if moe_type == "w4afp8" and inter_s // moe_tp % 128 != 0:
                continue

            if moe_type == "fp8_block" and sm_version >= 120 and _is_trtllm_130rc5_or_rc10_runtime():
                # DeepGEMM in TRT-LLM 1.3.0rc5/1.3.0rc10 rejects SM120 MoE
                # with "Unknown recipe" before any supported row can be collected.
                continue

            # fp8_block requires hidden_size divisible by block group_size (128)
            if moe_type == "fp8_block" and (
                common_moe_testcase.hidden_size % 128 != 0 or (inter_s // moe_tp) % 128 != 0
            ):
                continue

            # Blackwell DeepGEMM fp8_block has an additional TP-shard alignment requirement.
            # Skip shapes that are known to trigger layout assert:
            #   Assertion error ... layout.hpp:78: sf.size(-2) == ceil_div(mn, gran_mn)
            if moe_type == "fp8_block" and sm_version >= 100 and (common_moe_testcase.inter_size // moe_tp) % 128 != 0:
                continue

            # TLLM_CHECK_WITH_INFO(inter_size % (256 / sizeof_bits<WeightType>::value) == 0
            weight_bits = {
                "bfloat16": 16,
                "fp8": 8,
                "fp8_block": 8,
                "int4_wo": 4,
                "w4a16_mxfp4": 4,
                "w4a8_mxfp4_mxfp8": 4,
                "w4afp8": 4,
                "nvfp4": 4,
            }[moe_type]
            if (inter_s // moe_tp) % (256 // weight_bits) != 0:
                continue

            if (
                moe_type == "nvfp4"
                and sm_version >= 120
                and _is_trtllm_130rc5_runtime()
                and common_moe_testcase.num_experts // common_moe_testcase.ep < common_moe_testcase.topk
            ):
                # These standalone EP shapes crash the 1.3.0rc5 SM120 nvfp4 dry-run
                # kernel. WideEP collectors cover the large-EP MoE path separately.
                continue

            min_latency_mode_options = [False]

            if moe_type == "nvfp4" and get_sm_version() == 100 and common_moe_testcase.num_experts <= 256:
                # FIXME: recent version only supports SM100 for min-latency mode.
                # current support, DS router only support up to 256 experts.
                # Renormalize router only support <=128 experts. trtllmgen kernels only
                # support renormalize, ds and llama router.
                min_latency_mode_options.append(True)

            for min_latency_mode in min_latency_mode_options:
                num_tokens_list = common_moe_testcase.num_tokens_list
                if not num_tokens_list:
                    continue
                execution_key = _moe_execution_key(common_moe_testcase, moe_type, min_latency_mode)
                if execution_key in seen:
                    continue
                consumer_keys = _moe_consumer_keys(common_moe_testcase, moe_type, min_latency_mode)
                for consumer_key in consumer_keys:
                    previous_owner = consumer_key_owners.get(consumer_key)
                    if previous_owner is not None and previous_owner[0] != execution_key:
                        previous_model = previous_owner[1]
                        raise ValueError(
                            "TRT-LLM MoE population collision: "
                            f"models {previous_model!r} and {model_name!r} map distinct benchmark "
                            f"invocations to consumer key {consumer_key!r}; "
                            "the current moe_perf consumer cannot represent both"
                        )
                for consumer_key in consumer_keys:
                    consumer_key_owners[consumer_key] = (execution_key, model_name)
                seen.add(execution_key)
                test_cases.append(
                    [
                        moe_type,
                        num_tokens_list,
                        common_moe_testcase.hidden_size,
                        common_moe_testcase.inter_size,
                        common_moe_testcase.topk,
                        common_moe_testcase.num_experts,
                        common_moe_testcase.tp,
                        common_moe_testcase.ep,
                        min_latency_mode,
                        common_moe_testcase.model_name,
                        common_moe_testcase.token_expert_distribution,
                        common_moe_testcase.power_law_alpha,
                    ]
                )

    # Try to optimize number of autotune cache hits by shuffling test cases.
    # This makes sure the same cache keys are far apart from each other.
    random.seed(42)
    random.shuffle(test_cases)

    return test_cases


def run_moe_torch(
    moe_type,
    num_tokens_lists,
    hidden_size,
    inter_size,
    topk,
    num_experts,
    moe_tp_size,
    moe_ep_size,
    min_latency_mode,
    model_name,
    distributed="power_law",
    power_law_alpha=0.0,
    *,
    perf_filename,
    device="cuda:0",
):
    """Run MoE forward passes and log latency/power to perf file (trtllm >= 1.1 collector)."""
    device = torch.device(device)
    torch.cuda.set_device(device)
    torch.set_default_device(device)

    gc_collect()

    if aic_debug == 1:
        print("MOE Allocated GDRAM:", torch.cuda.memory_allocated(device.index) / 1024**2, "MB")
        print("MOE Reserved GDRAM:", torch.cuda.memory_reserved(device) / 1024**2, "MB")
    # moe type support bfloat16, fp8_qdq, fp8_block, w4a8, nvfp4(not implemented yet)
    dtype = torch.bfloat16
    quant_group_size = 128
    quant_algo = None
    if moe_type == "fp8_block":
        quant_algo = QuantAlgo.FP8_BLOCK_SCALES
        dtype = torch.float8_e4m3fn
    elif moe_type == "w4afp8":
        quant_algo = QuantAlgo.W4A8_AWQ
        dtype = torch.float8_e4m3fn
    elif moe_type == "fp8":
        quant_algo = QuantAlgo.FP8
        dtype = torch.float8_e4m3fn
    elif moe_type == "int4_wo":
        quant_algo = QuantAlgo.W4A16
        int4_config = get_moe_quantization_module_config("trtllm", moe_type, model_name=model_name)
        quant_group_size = int(int4_config.get("group_size", 128))
    elif moe_type == "nvfp4":
        quant_algo = QuantAlgo.NVFP4
        quant_group_size = 16
    elif moe_type == "w4a16_mxfp4":
        quant_algo = QuantAlgo.W4A16_MXFP4
        quant_group_size = 32
    elif moe_type == "w4a8_mxfp4_mxfp8":
        quant_algo = QuantAlgo.W4A8_MXFP4_MXFP8
        quant_group_size = 32

    if power_law_alpha - 0.0 < 1e-6:
        distributed = "balanced"

    quant_config = QuantConfig(
        quant_algo=quant_algo,
        kv_cache_quant_algo=None,
        group_size=quant_group_size,  # need to evaluate the impact of group size
        smoothquant_val=0.5,
        clamp_val=None,
        use_meta_recipe=False,
        has_zero_point=False,
        pre_quant_scale=False,
        exclude_modules=None,
    )

    # parallel mapping
    mapping = Mapping()
    mapping.moe_ep_size = moe_ep_size
    mapping.moe_tp_size = moe_tp_size

    # Create a minimal pretrained_config with required attributes for TensorRT-LLM 1.3+
    # The CommunicationFactory.create_strategy() accesses model_config.pretrained_config.hidden_size
    pretrained_config = SimpleNamespace(
        hidden_size=hidden_size,
        intermediate_size=inter_size,
        num_experts=num_experts,
        torch_dtype=torch.bfloat16,
    )

    model_config = ModelConfig(pretrained_config=pretrained_config)
    model_config.mapping = mapping
    model_config.quant_config = quant_config
    model_config.moe_max_num_tokens = num_tokens_lists[-1]  # to avoid multi-chunk auxi stream in cuda-graph mode.
    swiglu_alpha = None
    swiglu_beta = None
    swiglu_limit = None

    # Determine activation type based on model
    # Nemotron-3 Nano uses non-gated MoE with Relu2 activation
    # Other models (DeepSeek, Qwen, Mixtral) use gated MoE with SwiGLU activation
    if any(pattern in model_name for pattern in NON_GATED_MOE_MODELS):
        if ActivationType is None:
            raise RuntimeError(
                f"TensorRT-LLM {_TRTLLM_VERSION} does not expose ActivationType; "
                f"cannot collect non-gated MoE model {model_name}"
            )
        activation_type = ActivationType.Relu2
        is_gated = False
    else:
        activation_type = ActivationType.Swiglu if ActivationType is not None else None
        is_gated = True

    sm_version = get_sm_version()

    if model_name in ["openai/gpt-oss-120b", "openai/gpt-oss-20b"]:
        swiglu_alpha = torch.tensor([1.702] * (num_experts // moe_ep_size), dtype=torch.float32).to(
            torch.device(device)
        )
        swiglu_beta = torch.tensor([1.0] * (num_experts // moe_ep_size), dtype=torch.float32).to(torch.device(device))
        swiglu_limit = torch.tensor([7.0] * (num_experts // moe_ep_size), dtype=torch.float32).to(torch.device(device))
        if 86 < get_sm_version() < 100:
            # Hopper: use triton backend for best performance
            model_config.moe_backend = "triton"
        elif get_sm_version() >= 100:
            # Blackwell: production uses TRTLLMGenFusedMoE (Bf16MxE2m1BlockScaleMoeRunner)
            model_config.moe_backend = "trtllm"
        else:
            model_config.moe_backend = "cutlass"
    else:
        # Select backend based on platform and quant mode.
        if min_latency_mode:
            model_config.moe_backend = "trtllm"
        elif moe_type in _MXFP4_MOE_TYPES and sm_version >= 100:
            # Blackwell MXFP4 MoE is implemented by TRTLLMGenFusedMoE; CUTLASS
            # rejects WFP4A16 on SM100.
            model_config.moe_backend = "trtllm"
        elif moe_type == "fp8_block":
            if sm_version >= 100:
                # Blackwell: DeepGEMM uses MXFP8 style (E4M3 + UE8M0 scale).
                model_config.moe_backend = "deepgemm"
            else:
                # Hopper: CUTLASS uses FP32 scale.
                model_config.moe_backend = "cutlass"
        else:
            model_config.moe_backend = "cutlass"

    router_logits_dtype = torch.bfloat16
    # current min_latency mode only support experts <= 256. Thus K2 will not have min_latency mode.
    if min_latency_mode:
        # FIXME: all use deepseek setting for now.
        n_group = 8
        topk_group = 4
        routed_scaling_factor = 2.5

        routing_method = DeepseekV3Gate(
            hidden_size,
            num_experts,
            top_k=topk,
            n_group=n_group,
            topk_group=topk_group,
            routed_scaling_factor=routed_scaling_factor,
            dtype=dtype,
            moe_backend="TRTLLM",
        ).routing_method
        router_logits_dtype = torch.float32
    else:
        # for low latency mode in fp4, experts > 128 is not supported.
        routing_method = RenormalizeMoeRoutingMethod(topk)

    create_moe_kwargs = {
        "routing_method": routing_method,
        "num_experts": num_experts,
        "hidden_size": hidden_size,
        "intermediate_size": inter_size,
        "dtype": dtype,
        # In both low latency and attention dp scenarios, create_moe needs not to do allreduce
        # inside op.
        "reduce_results": False,
        "model_config": model_config,
    }
    create_moe_params = inspect.signature(create_moe).parameters
    if "swiglu_alpha" in create_moe_params:
        create_moe_kwargs["swiglu_alpha"] = swiglu_alpha
    if "swiglu_beta" in create_moe_params:
        create_moe_kwargs["swiglu_beta"] = swiglu_beta
    if "swiglu_limit" in create_moe_params:
        create_moe_kwargs["swiglu_limit"] = swiglu_limit
    if "activation_type" in create_moe_params and activation_type is not None:
        create_moe_kwargs["activation_type"] = activation_type
    moe = create_moe(**create_moe_kwargs)
    moe.to(torch.device(device))

    # SM100 (Blackwell) DeepGEMM expects weight scales (SFB) in int32 UE8M0 format,
    # but create_moe() initializes them as float32. TRT-LLM's post_load_weights()
    # normally handles this conversion after loading real weights, but AIC uses
    # random weights without calling load_weights() for fp8_block. We must do
    # the conversion here to avoid cudaErrorIllegalAddress from TMA OOB access.
    if moe_type == "fp8_block" and sm_version >= 100:
        from tensorrt_llm.quantization.utils.fp8_utils import transform_sf_into_required_layout

        moe_backend = getattr(moe, "backend", moe)
        quant_scales = getattr(moe, "quant_scales", None)
        if quant_scales is None:
            quant_scales = moe_backend.quant_scales

        # Transform w3_w1 weight scales: float32 [G, N/128, K/128] -> int32 UE8M0 [G, N, sf_k_tma]
        transformed_w3w1 = transform_sf_into_required_layout(
            quant_scales[0],
            mn=moe_backend.w3_w1_weight.shape[1],
            k=moe_backend.w3_w1_weight.shape[2],
            recipe=(1, 128, 128),
            num_groups=moe_backend.w3_w1_weight.shape[0],
            is_sfa=False,
        )
        moe_backend.w3_w1_weight_scaling_factor = torch.nn.Parameter(transformed_w3w1, requires_grad=False)
        # Transform w2 weight scales
        transformed_w2 = transform_sf_into_required_layout(
            quant_scales[1],
            mn=moe_backend.w2_weight.shape[1],
            k=moe_backend.w2_weight.shape[2],
            recipe=(1, 128, 128),
            num_groups=moe_backend.w2_weight.shape[0],
            is_sfa=False,
        )
        moe_backend.w2_weight_scaling_factor = torch.nn.Parameter(transformed_w2, requires_grad=False)
        # Rebuild quant_scales tuple with the transformed tensors
        moe_backend.quant_method.setup_quant_scales(moe_backend)
        if aic_debug == 1:
            print("[SM100 fix] Converted weight scales to int32 UE8M0 format")

    # Both w4a16_mxfp4 and w4a8_mxfp4_mxfp8 use MXFP4 weights and share the same
    # weight loading path in TRT-LLM (inherited from MXFP4WeightTRTLLMGenFusedMoEMethod).
    # We must explicitly cast weights to MXFP4 format and call load_weights() so that
    # the proper shuffle/permutation (torch.ops.trtllm.shuffle_matrix) is applied,
    # which the kernel expects for correct memory access patterns.
    if moe_type in ("w4a16_mxfp4", "w4a8_mxfp4_mxfp8"):
        local_num_experts = num_experts // moe_ep_size
        w1_bias = torch.randn((local_num_experts, inter_size), dtype=dtype, device=device)
        w2_bias = torch.randn((local_num_experts, hidden_size), dtype=dtype, device=device)
        w3_bias = torch.randn((local_num_experts, inter_size), dtype=dtype, device=device)

        from triton_kernels.numerics_details.mxfp import downcast_to_mxfp_torch

        def fp32_to_mxfp4(tensor):
            tensor = tensor.transpose(1, 2).contiguous()
            tensor_fp4, tensor_scales = downcast_to_mxfp_torch(tensor, torch.uint8, axis=1)
            tensor_fp4 = tensor_fp4.transpose(1, 2).contiguous()
            tensor_scales = tensor_scales.transpose(1, 2).contiguous()
            return tensor_fp4, tensor_scales

        # Convert one weight tensor at a time to lower peak memory.
        w1_weight = torch.randn((local_num_experts, inter_size, hidden_size), dtype=dtype, device=device)
        w1_weight_fp4, w1_weight_scale = fp32_to_mxfp4(w1_weight)
        del w1_weight
        torch.cuda.empty_cache()

        w2_weight = torch.randn((local_num_experts, hidden_size, inter_size), dtype=dtype, device=device)
        w2_weight_fp4, w2_weight_scale = fp32_to_mxfp4(w2_weight)
        del w2_weight
        torch.cuda.empty_cache()

        w3_weight = torch.randn((local_num_experts, inter_size, hidden_size), dtype=dtype, device=device)
        w3_weight_fp4, w3_weight_scale = fp32_to_mxfp4(w3_weight)
        del w3_weight
        torch.cuda.empty_cache()

        weights = {}
        for expert_id in range(local_num_experts):
            weights[f"{expert_id}.w1.weight"] = w1_weight_fp4[expert_id]
            weights[f"{expert_id}.w2.weight"] = w2_weight_fp4[expert_id]
            weights[f"{expert_id}.w3.weight"] = w3_weight_fp4[expert_id]
            weights[f"{expert_id}.w1.weight_scale"] = w1_weight_scale[expert_id]
            weights[f"{expert_id}.w2.weight_scale"] = w2_weight_scale[expert_id]
            weights[f"{expert_id}.w3.weight_scale"] = w3_weight_scale[expert_id]
            weights[f"{expert_id}.w1.bias"] = w1_bias[expert_id]
            weights[f"{expert_id}.w2.bias"] = w2_bias[expert_id]
            weights[f"{expert_id}.w3.bias"] = w3_bias[expert_id]
        moe.load_weights([weights])

    # dry run
    torch.cuda.synchronize()
    max_tokens = num_tokens_lists[-1]
    for i in range(len(num_tokens_lists)):
        max_tokens = num_tokens_lists[-i - 1]
        try:
            hidden_states_max_tokens = torch.randn([max_tokens, hidden_size]).bfloat16().to(torch.device(device))
            logits_max_tokens = balanced_logits(max_tokens, num_experts, topk).to(router_logits_dtype)
            moe.forward(hidden_states_max_tokens, logits_max_tokens, do_finalize=not min_latency_mode)
            torch.cuda.synchronize()
            if aic_debug == 1:
                print(f"Successfully dry run for {max_tokens} tokens")
            break
        except Exception as e:
            accelerator_error = getattr(torch, "AcceleratorError", None)
            if accelerator_error is not None and isinstance(e, accelerator_error):
                raise
            if i == len(num_tokens_lists) - 1:
                raise RuntimeError(f"dry run failed for {max_tokens} tokens: {e}") from e
            else:
                continue

    if moe_type != "w4a16_mxfp4":
        cleanup_empty_json_files(moe_tune_path)
        cache_path = (
            f"{moe_tune_path}/{moe_type}_{hidden_size}_{inter_size // moe_tp_size}_{num_experts // moe_ep_size}"
        )
        existing_files = glob.glob(f"{cache_path}*")
        cache_loaded = False
        if existing_files:
            json_path = existing_files[0]
            try:
                load_cache = AutoTuner.get().profiling_cache.load_cache
                if "rank" in inspect.signature(load_cache).parameters:
                    load_cache(json_path, rank=device.index)
                else:
                    load_cache(json_path)
                cache_loaded = True
                print(f"Loaded profiling cache from {json_path}")
            except (OSError, json.JSONDecodeError):
                pass

        if not cache_loaded:
            torch.cuda.synchronize()
            for i in range(len(num_tokens_lists)):
                max_tokens_for_tuning = num_tokens_lists[-i - 1]
                if max_tokens_for_tuning > max_tokens:
                    continue
                else:
                    try:
                        # Check which autotune() kwargs are accepted. These
                        # moved across TRT-LLM torch-flow releases.
                        autotune_params = inspect.signature(autotune).parameters
                        autotune_kwargs = {}
                        if "cache_path" in autotune_params:
                            autotune_kwargs["cache_path"] = cache_path
                        if "rank" in autotune_params:
                            autotune_kwargs["rank"] = torch.device(device).index

                        with torch.inference_mode(), autotune(**autotune_kwargs):
                            moe.forward(
                                hidden_states_max_tokens[:max_tokens_for_tuning],
                                logits_max_tokens[:max_tokens_for_tuning],
                                do_finalize=not min_latency_mode,
                            )
                        torch.cuda.synchronize()
                    except Exception as e:
                        print(f"tune failed for {max_tokens_for_tuning} tokens: {e}, fallback to samller tokens")
                        continue

    del hidden_states_max_tokens, logits_max_tokens
    if moe_type == "fp8_block":
        try:
            from tensorrt_llm._torch.modules.fused_moe.fused_moe_deepgemm import DeepGemmFusedMoE

            DeepGemmFusedMoE.buffers.buffers.clear()
        except (ImportError, AttributeError):
            pass
        torch.cuda.empty_cache()

    for num_tokens in num_tokens_lists:
        # gc_collect()

        if num_tokens > max_tokens:
            continue
        hidden_states = torch.randn([num_tokens, hidden_size]).bfloat16().to(torch.device(device))
        num_iter = 5 if distributed == "power_law" else 1
        if distributed == "power_law":
            actual_logits_list = [
                power_law_logits_v3(num_tokens, num_experts, topk, moe_ep_size, power_law_alpha)
                .to(router_logits_dtype)
                .to(device)
                for _ in range(num_iter)
            ]
        elif distributed == "balanced":
            actual_logits = balanced_logits(num_tokens, num_experts, topk).to(
                device=torch.device(device), dtype=router_logits_dtype
            )
        else:
            raise ValueError(f"Unsupported distributed mode: {distributed}")

        # ═══════════════════════════════════════════════════════════════════════════════
        # Helper closure to encapsulate forward pass logic (reduces duplication)
        # ═══════════════════════════════════════════════════════════════════════════════
        def run_forward_pass():
            """Execute one forward pass through MOE, handling both power_law and balanced modes."""
            if distributed == "power_law":
                for logits in actual_logits_list:
                    moe.forward(hidden_states, logits, do_finalize=not min_latency_mode)  # noqa: F821
            else:
                moe.forward(hidden_states, actual_logits, do_finalize=not min_latency_mode)  # noqa: F821

        # ═══════════════════════════════════════════════════════════════════════════════
        # Benchmark with automatic power measurement and graph fallback
        # ═══════════════════════════════════════════════════════════════════════════════
        # Determine base warmups and runs based on distribution mode
        num_warmups = 1 if distributed == "power_law" else 3
        num_runs = 1 if distributed == "power_law" else 6

        # Use benchmark_with_power with graceful graph fallback
        with benchmark_with_power(
            device=device,
            kernel_func=run_forward_pass,
            num_warmups=num_warmups,
            num_runs=num_runs,
            repeat_n=1,
            allow_graph_fail=True,  # Enable graceful fallback to eager execution
        ) as results:
            # Calculate per-iteration latency (accounting for internal iterations)
            latency = results["latency_ms"] / num_iter
            power_stats = results["power_stats"]

            # Log if CUDA graph capture failed (for debugging)
            if not results["used_cuda_graph"] and aic_debug == 1:
                print(f"CUDA graph capture failed for {num_tokens} tokens, used eager execution fallback")

        if moe_type == "fp8_block" and sm_version >= 100:
            source = "deepgemm"
        elif min_latency_mode:
            source = "moe_torch_flow_min_latency"  # trtllm gen
        elif not is_gated:
            source = "moe_torch_flow_nongated"  # non-gated MoE (relu2)
        elif model_config.moe_backend == "cutlass":
            source = "moe_torch_flow_cutlass"  # SM90 CUTLASS (FP32 scale)
        else:
            source = "moe_torch_flow"  # default

        log_perf(
            item_list=[
                {
                    "moe_dtype": moe_type,
                    "num_tokens": num_tokens,
                    "hidden_size": hidden_size,
                    "inter_size": inter_size,
                    "topk": topk,
                    "num_experts": num_experts,
                    "moe_tp_size": moe_tp_size,
                    "moe_ep_size": moe_ep_size,
                    "distribution": "power_law_" + str(power_law_alpha) if distributed == "power_law" else distributed,
                    "latency": latency,
                }
            ],
            framework="TRTLLM",
            version=tensorrt_llm.__version__,
            device_name=torch.cuda.get_device_name(device),
            op_name="moe",
            kernel_source=source,
            perf_filename=perf_filename,
            power_stats=power_stats,
        )
        if distributed == "power_law":
            del actual_logits_list
        else:
            del actual_logits
        del hidden_states
        if moe_type == "fp8_block" and num_tokens != max_tokens:
            try:
                from tensorrt_llm._torch.modules.fused_moe.fused_moe_deepgemm import DeepGemmFusedMoE

                DeepGemmFusedMoE.buffers.buffers.clear()
            except (ImportError, AttributeError):
                pass
            torch.cuda.empty_cache()

    if os.getenv("TRTLLM_MOE_RESTART_WORKER", "1") != "0":
        # Exit the worker process after completing MOE task to ensure complete resource cleanup.
        # This forces OS to reclaim all GPU memory, CUDA context, and other resources.
        sys.exit(EXIT_CODE_RESTART)


if __name__ == "__main__":
    from collector.registry_types import PerfFile

    test_cases = get_moe_test_cases()
    for test_case in test_cases:
        run_moe_torch(*test_case, perf_filename=PerfFile.MOE)
